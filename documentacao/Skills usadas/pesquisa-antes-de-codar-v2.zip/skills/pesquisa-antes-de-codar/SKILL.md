---
name: "pesquisa-antes-de-codar"
description: "Ao criar, alterar, depurar ou integrar código real: conferir versão e doc oficial, planejar curto e verificar rodando. Não usar em dúvida conceitual ou script descartável."
compatibility: Requer acesso a leitura de arquivos e execução de comandos no projeto. A etapa de pesquisa precisa de busca ou fetch na web; sem isso, declare a limitação em vez de codar de memória.
---

# Pesquisa antes de codar

Duas coisas quebram trabalho com código assistido por modelo: usar API que não
existe (ou existe em outra versão), e dizer que funcionou sem ter rodado. As
fases abaixo existem só para fechar essas duas portas. O resto é o de sempre.

Peso proporcional à tarefa. Trocar uma string não precisa de plano; integrar
uma biblioteca nova precisa das cinco fases. A régua está no fim, em "Quando
não aplicar".

## Fase 0 — Terreno

Antes de pesquisar qualquer coisa, descubra o que já existe. Pesquisar a
documentação da versão errada é pior que não pesquisar, porque produz código
plausível e quebrado.

- Versões reais, lidas do projeto e não presumidas: `package.json` + lockfile,
  `requirements.txt`, `pyproject.toml`, `pip freeze`, `go.mod`, `Cargo.toml`,
  `platformio.ini`. O lockfile manda mais que o manifesto.
- Como o projeto roda e testa: script de teste, linter, comando de build.
- Se existe código no repositório que já faz algo parecido. O padrão do
  projeto ganha do padrão da documentação.

Anote o que encontrou em uma ou duas linhas. Isso é o que vai orientar a
pesquisa da fase seguinte.

## Fase 1 — Pesquisa

Aplica quando a tarefa toca API, biblioteca, framework, protocolo ou serviço
externo. Não aplica para lógica pura, algoritmo, estrutura de dados ou
refatoração interna — nesses casos pule direto para a fase 2 e diga que pulou.

- Busque a documentação oficial **da versão que está instalada**. Se a doc
  online só cobre uma versão diferente, isso é informação relevante: diga.
- Prefira, nesta ordem: doc oficial → changelog/release notes da versão →
  código-fonte da própria dependência (está instalado, dá para ler) → issues
  do repositório. Blog e resposta de fórum servem para achar o caminho, não
  para confirmar assinatura de função.
- Guarde a URL do que leu. Ela entra no relatório final.
- Se a busca não confirmar o que você precisa, o certo é escrever "não
  confirmei a assinatura de X" e seguir marcando o trecho. Inventar um
  parâmetro plausível é o pior resultado possível, porque parece certo.

Regra de origem: toda chamada de API no código que você escrever precisa vir
de (a) documentação que você leu agora, (b) código que já existe no
repositório, ou (c) marcação explícita de que não foi verificada. Não existe
quarta opção.

## Fase 2 — Plano

Antes de escrever o código, escreva o plano. Curto, no chat, sem virar
documento:

```
Mudança: <uma frase>
Arquivos: <lista>
Como vou verificar: <comando concreto que roda e o resultado esperado>
Se der errado: <como desfazer>
Fora de escopo: <o que eu poderia fazer junto e não vou fazer>
```

Se a mudança toca mais de três arquivos, mexe em migração de banco,
autenticação, deploy, ou apaga coisa, pare aqui e espere confirmação. Caso
contrário siga direto — pedir permissão para tudo cansa e não protege de nada.

A linha "Como vou verificar" não é enfeite. Se você não consegue escrever um
comando concreto ali, você ainda não entendeu a tarefa, e é hora de perguntar
em vez de codar.

## Fase 3 — Implementação

- A menor mudança que resolve o problema. Reescrever o módulo inteiro quando
  cabia uma linha destrói contexto que o usuário tinha na cabeça.
- Um passo por vez, rodando entre os passos. Vinte arquivos alterados e só
  então rodar transforma um erro pequeno em caçada.
- Siga o estilo do arquivo que você está editando, mesmo que você prefira
  outro. Consistência vale mais que gosto.
- Não altere formatação, imports ou nomes fora do escopo. Isso polui o diff e
  esconde a mudança real.
- Comente só o que não é óbvio pelo código: o porquê, não o quê.

## Fase 4 — Verificação

Esta fase substitui as "notas de qualidade" que sistemas parecidos usam. Uma
nota que o próprio modelo se dá não mede nada. O que mede é a saída de um
comando.

- Rode. Teste existente, script, `python -c`, `node -e`, `curl`, o que der.
- Sem teste no projeto: escreva o menor comando que prova que funciona e
  mostre a saída dele.
- Confira o caso de erro, não só o caminho feliz. Entrada vazia, arquivo que
  não existe, rede fora.
- Não deu para rodar (falta credencial, falta hardware, ambiente diferente):
  diga isso na cara, aponte o que exatamente ficou sem prova e como o usuário
  testa.

Rotule cada afirmação sobre o resultado com um destes três:

- rodei e passou — colar a saída
- confirmado na doc, não rodado — colar a URL
- não verificado — dizer o que falta para verificar

Misturar os três sem distinção é o comportamento que essa skill existe para
impedir.

## Trava das duas tentativas

Falhou duas vezes na mesma coisa, pare. Não tente uma terceira variação.
Reporte: o que tentou, o erro exato, as duas ou três hipóteses que sobraram e
o que você precisa (um log, uma versão, uma decisão). Insistir sozinho depois
da segunda falha costuma piorar o estado do código em vez de melhorar.

## Nunca para fazer o teste passar

Estas cinco coisas fazem a barra ficar verde escondendo o problema, e por isso
não entram jamais:

- apagar ou pular teste que está falhando
- afrouxar a asserção para caber no resultado errado
- `try/except` vazio, `catch {}` ou `# type: ignore` para calar o erro
- valor fixo devolvido no lugar da lógica que devia calcular
- mexer no teste quando quem está errado é o código

Se o teste está errado mesmo, diga por que está errado e proponha a correção
separada da mudança principal.

## Relatório final

Feche assim, sem enfeite:

```
Fiz: <o que mudou, em uma ou duas linhas>
Verifiquei: <comando + saída>
Não verifiquei: <o que ficou sem prova e por quê>
Assumi: <decisão que tomei sozinha e o usuário pode querer mudar>
Fontes: <URLs da doc que sustentam o código>
```

O bloco "Não verifiquei" quase nunca fica vazio, e isso é bom sinal. Relatório
sem ele é relatório escondendo coisa.

## Quando não aplicar

Não use isso para dúvida conceitual, explicação de algoritmo, pseudocódigo,
one-liner de shell, ou script descartável que o usuário vai rodar uma vez e
jogar fora. Processo em cima de tarefa de dois minutos é burocracia e o
usuário vai desligar a skill. Nesses casos responda direto — no máximo
mantenha o rótulo de verificação da fase 4, que custa uma linha.