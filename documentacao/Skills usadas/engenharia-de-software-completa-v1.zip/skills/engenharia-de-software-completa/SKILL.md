---
name: engenharia-de-software-completa
description: "Síntese operacional de onze obras de engenharia de software (Brooks, Hunt & Thomas, Martin, Fowler, Evans, GoF, Richards & Ford, Sommerville, Pressman, Bhargava, Valente). Use SEMPRE que houver trabalho de software: entender requisitos, escrever histórias de usuário ou casos de uso, definir MVP, modelar domínio, desenhar UML, decidir arquitetura ou tecnologia (camadas, MVC, microserviços, filas, pub/sub), escrever/revisar/nomear código, medir métricas de código, projetar testes (unidade, integração, sistema, cobertura, mocks, TDD), refatorar, lidar com legado, escolher algoritmo ou estrutura de dados, otimizar desempenho, estimar prazo, rodar Scrum/Kanban/XP, montar CI/CD, DevOps, Git, versionamento, organizar equipe, avaliar risco, discutir ética profissional, ou decidir entre abordagens conflitantes (ágil x plano, herança x composição, DRY x acoplamento, projeto antecipado x emergente, comentar x não comentar, monolito x microserviços)."
---

# Engenharia de Software — síntese operacional de onze obras fundamentais

Referência para **planejar, projetar, implementar, testar, evoluir e manter software**. Conteúdo extraído e reconciliado de onze livros (mapa das fontes no fim). Nada depende de linguagem, framework ou stack: onde um autor usou Java, C++ ou Smalltalk, o raciocínio foi generalizado para o mecanismo subjacente.

O objetivo não é reproduzir conceitos, e sim **reproduzir o modo de pensar** dos autores: o que olham primeiro, que pergunta fazem antes de decidir, que sinal os faz mudar de rumo, e o que fazem quando dois princípios corretos se contradizem.

---

## 0. Como usar

| Situação | Vá para |
|---|---|
| Começar algo novo | §2 → §3 → §4 → §5 |
| Escrever/alterar código agora | §1 → §6 → §7 |
| Código ruim que preciso mexer | §8 → §6 |
| Decidir arquitetura / tecnologia | §5 → §11 |
| Está lento | §9 |
| Que rigor este sistema merece? | §1.2 (antes de tudo) |
| Escrever requisito para o time (história, caso de uso, MVP) | §2.4 → §2.7 |
| Desenhar um diagrama para explicar algo | §4.8 |
| Escolher/entender um estilo concreto (camadas, MVC, microserviços, filas) | §5.11 |
| Medir qualidade interna com números | §5.12 |
| Montar a estratégia de testes de um sistema | §7.5 → §7.10 |
| Rodar o processo no dia a dia (XP, Scrum, Kanban) | §10.7 |
| Versionar, integrar, implantar, automatizar entrega | §10.8 |
| Pediram algo que parece errado | §10.9 |
| Estimar, planejar, organizar equipe | §10 |
| Dois princípios se contradizem | §11 (obrigatório) |
| Fechar/entregar | §13 |

**Precedência interna:** quando duas seções conflitarem, §11 decide. §11 é onde mora o julgamento que os autores exercem tacitamente.

---

## 1. Axiomas — onde os autores concordam

1. **A dificuldade essencial do software é conceitual, não mecânica.** Brooks separa dificuldades *essenciais* (complexidade, conformidade, mutabilidade, invisibilidade) das *acidentais* (linguagem, ferramenta, sintaxe). Ferramentas atacam o acidental; só design e entendimento atacam o essencial. Nenhuma ferramenta ou processo compra ordem de grandeza.

2. **A complexidade cresce de forma não linear com o tamanho.** Ampliar um sistema não é repetir elementos iguais — é aumentar o número de elementos *diferentes*, que interagem de modo não linear. Particionar bem é a alavanca central; "só mais um caso especial" nunca custa o que parece.

3. **Todo software bem-sucedido é alterado.** Brooks: o produto vive numa matriz de usuários, leis e plataformas, todas mudando. Lehman: um programa deve mudar continuamente para continuar útil, e ao mudar sua estrutura degrada. **O custo dominante do software é o custo da mudança**, não o da primeira escrita. Todo princípio abaixo existe para reduzir esse custo.

4. **Tudo é trade-off** (Primeira Lei da Arquitetura de Software). Se você acha que achou algo sem contrapartida, ainda não identificou a contrapartida. Rich Hickey, citado por Richards & Ford: *"programadores conhecem os benefícios de tudo e os trade-offs de nada"*.

5. **O porquê importa mais que o como** (Segunda Lei). Você reconstrói *como* um sistema funciona olhando o código; não reconstrói *por que* aquelas escolhas foram feitas. A justificativa é o artefato mais perecível e o mais valioso — registre-a (ADR, §5.7).

6. **Código é lido muito mais do que escrito, e por outra pessoa.** Martin: a proporção de tempo lendo versus escrevendo é da ordem de **10 para 1**. Hooker (via Pressman), 4º princípio: *o que um produz, outros consomem* — especifique pensando no usuário, projete pensando em quem implementa, codifique pensando em quem vai manter e depurar.

7. **Feedback rápido e concreto vale mais que previsão.** Manifesta-se como código rastreador (Hunt), crescimento incremental (Brooks/Mills), testes automatizados (Martin/Fowler), integração contínua (Evans), iteração (Sommerville/Pressman), último momento responsável (Richards & Ford).

8. **O modelo mental do domínio é parte do software.** Evans: o modelo é a espinha dorsal da linguagem; Brooks: integridade conceitual é a consideração mais importante do projeto; Hunt: programe num nível próximo ao domínio do problema. Um sistema cujo código não fala a língua do problema já está em dívida.

9. **Qualidade é requisito, não sobra.** Hunt (Dica 7): torne a qualidade parte dos requisitos e envolva o usuário na decisão de "bom o suficiente". "Satisfatório" não significa malfeito — significa que o escopo de qualidade foi **decidido explicitamente**.

10. **Não programe por coincidência** (Hunt, Dica 44). Saiba por que seu código funciona. Se não sabe explicar por que passou, não sabe se passou. Vale igualmente para código gerado por assistente: *não use um código de assistente que você não entender* (Dica 50).

11. **Rigor é calibrado ao custo da falha, não ao gosto do engenheiro.** Valente organiza o livro inteiro em torno dessa calibragem (§1.2): a mesma prática que é indispensável num sistema de missão crítica é desperdício num script de conversão de dados. **Over-engineering é falha simétrica ao under-engineering** — "usar uma bala de canhão para matar formigas". Antes de aplicar qualquer regra desta skill, pergunte em que classe de sistema você está.

12. **Automatizar o caminho até produção é decisão de engenharia, não de infraestrutura.** Controle de versões, build, testes e implantação de um comando cada (Hunt) e integração contínua (Evans, XP, Valente) são o que permite que todas as outras práticas funcionem: sem eles, refatorar assusta, testar cansa e entregar vira evento. §10.8.

13. **Testes mostram a presença de bugs, nunca a sua ausência** (Dijkstra, citado por Valente). Toda estratégia de teste é escolha de *quais* bugs você quer que apareçam antes do usuário — nunca prova de correção. Por isso a pergunta operacional é sempre "que classe de defeito esta suíte detecta e qual ela deixa passar?", não "quantos % de cobertura temos?" (§7.6).

### 1.1 Vocabulário mínimo — termos que times usam errado

Estes termos aparecem em requisitos, bug trackers e reuniões; usá-los trocados custa retrabalho.

| Termo | Significado preciso |
|---|---|
| **Defeito** (= erro, falta/*fault*, e, no uso corrente, *bug*) | Código que não está de acordo com sua especificação. Existe mesmo que ninguém execute aquele trecho. |
| **Falha** (*failure*) | O que acontece **quando** o código defeituoso é executado e produz resultado incorreto. **Nem todo defeito gera falha** — pode nunca ser executado. |
| **Verificação** | *Estamos construindo o sistema corretamente?* Conformidade com a especificação. Teste de unidade é verificação. |
| **Validação** | *Estamos construindo o sistema correto?* Conformidade com a necessidade real do cliente. Teste de aceitação com o cliente é validação. |
| **Qualidade externa** | Aferível sem ler o código, inclusive por leigos: correção, robustez, eficiência, portabilidade, facilidade de uso, compatibilidade. |
| **Qualidade interna** | Só aferível por quem lê o código: modularidade, legibilidade, manutenibilidade, testabilidade. É o objeto de §5, §6 e §8. |
| **Requisito funcional** | *O que* o sistema faz. |
| **Requisito não funcional** | *Como* ele opera e sob que restrição: desempenho, disponibilidade, tolerância a falhas, segurança, privacidade, interoperabilidade, capacidade, manutenibilidade, usabilidade. Equivale, quando estrutural e essencial, à *característica arquitetural* de §2.1. |

A distinção verificação/validação **só faz sentido porque a especificação pode não expressar a necessidade** — ela existe justamente para dar nome a esse erro. Um sistema pode passar em 100% da verificação e falhar inteiro na validação; foi assim que se perdeu a maioria dos projetos que "entregaram tudo que estava no documento".

Escala de referência (SWEBOK): as **12 áreas de conhecimento** da disciplina são requisitos, projeto, construção, testes, manutenção, gerência de configuração, gerência de projetos, processos, modelos, qualidade, prática profissional e aspectos econômicos. Serve como checklist de cobertura: um projeto que nunca discutiu três dessas áreas provavelmente está pagando por isso em algum lugar.

**Versionamento semântico** (`x.y.z`): incremento em `z` = correção de bug (*patch*); em `y` = nova funcionalidade compatível (*minor*); em `x` = mudança incompatível (*major*). É contrato com quem depende de você, não numeração decorativa.

**Custo de oportunidade** é a variável econômica que decide a maior parte das discussões técnicas travadas: corrigir a lista de bugs B ou implementar as funcionalidades F? Escolher B não é "fazer o certo" — é abrir mão de F. Enuncie sempre as duas pontas antes de defender uma.

### 1.2 Calibragem ABC — que sistema é este?

Classificação de Meyer, adotada por Valente como filtro de aplicabilidade de tudo que a área recomenda:

| Classe | O que é | Risco dominante | Regime recomendado |
|---|---|---|---|
| **A — *Acute*** (missão crítica) | Falha custa vidas ou prejuízo imenso: controle de aeronave, usina nuclear, equipamento de UTI, carro autônomo, metrô. | Falha catastrófica. | Processo rígido, certificação externa, revisão formal, redundância em hardware **e** software, especificação formal. Vai **além** do que esta skill cobre. |
| **B — *Business*** | Aplicações corporativas, sistemas web, bibliotecas, frameworks, software básico (compiladores, SGBDs, IDEs). | Custo de mudança e defeito em produção. | **É o alvo desta skill.** Todo o restante do documento supõe sistemas B. |
| **C — Casuais** | Script de trabalho acadêmico, conversão de dados usada uma vez, sistema do diretório acadêmico, agendador de salas. 1–2 desenvolvedores, não crítico. | **Over-engineering.** | Qualidade interna alta não se paga; duplicação tolerável; desempenho e interface não são gargalo. |

**Uso operacional:** antes de exigir cobertura de testes, ADR, pipeline ou padrão de projeto, diga em voz alta a classe do sistema. Boa parte das discussões de "isso é exagero" x "isso é relaxamento" é, na verdade, divergência não declarada sobre a classe — e resolve-se nomeando-a. Cuidado com o erro comum: sistemas C que **viraram** B sem que ninguém percebesse (o script que virou processo mensal da empresa). Reclassificar é decisão explícita, com dívida a pagar.

---

## 2. Antes de escrever qualquer linha

### 2.1 Requisitos não são coletados, são escavados

Hunt & Thomas: **"não colete requisitos — cave-os"** (Dica 51). Requisitos estão enterrados sob suposições, políticas e vocabulário ambíguo. O trabalho é arqueológico.

1. **Trabalhe com um usuário para pensar como um usuário** (Dica 52). Não pergunte "o que você quer" — observe o trabalho. Muito do conhecimento operacional é tácito: *algumas coisas são fáceis de fazer, mas não de descrever* (Dica 57).
2. **Separe requisito de política.** "Só o supervisor aprova acima de X" é política (muda sempre); "aprovações têm limite de alçada" é requisito. Codifique o requisito; ponha a política em metadados (§6.8).
3. **Distinga requisito funcional de característica arquitetural.** Requisito diz *o que o sistema faz*. Característica arquitetural (Richards & Ford) atende **três critérios simultâneos**: (a) especifica consideração de design **fora do domínio**; (b) **influencia algum aspecto estrutural**; (c) é **essencial ou importante para o sucesso**. Se falha algum, não é característica arquitetural — é ruído. Exemplos: disponibilidade, escalabilidade, elasticidade, auditabilidade, testabilidade, implantabilidade, segurança.
4. **Mantenha um glossário do projeto vivo** (Dica 54). É a semente da UBIQUITOUS LANGUAGE (§4.1).
5. **Escreva a visão em uma página** (DOMAIN VISION STATEMENT, Evans): descreva o CORE DOMAIN e o valor que traz, ignorando o que não distingue este domínio de outros. Bússola para o time, legível por não técnicos.

### 2.2 A armadilha da especificação

Hunt: especificar até a exaustão é procrastinação disfarçada de rigor. Brooks reforça pelo lado oposto: a parte mais difícil é decidir precisamente o que construir, e nenhuma outra parte prejudica tanto o sistema se feita errado — **mas** conclui que a resposta não é especificar mais cedo, e sim **fazer o cliente ver e reagir**.

**Critério:** especifique até o ponto em que a próxima dúvida só pode ser resolvida por experimento, e então faça o experimento.

### 2.3 Protótipo vs. código rastreador

| | **Protótipo** | **Código rastreador (tracer bullet)** |
|---|---|---|
| Objetivo | Responder a uma pergunta arriscada | Conectar o sistema de ponta a ponta |
| Destino do código | **Descartável** | **Permanece — é o esqueleto do sistema final** |
| Rigor | Ignora precisão, integralidade, robustez, estilo | Tem verificação de erros, estrutura, documentação, testes |
| Quando | Arquitetura duvidosa, UI incerta, algoritmo novo, componente de terceiros, dúvida de desempenho | As peças talvez não conversem; requisitos vagos; precisa demonstrar progresso |

- **Prototipe qualquer coisa arriscada, não comprovada, experimental ou duvidosa.** O valor não está no código, e sim nas lições.
- **Declare que o protótipo é descartável antes de escrevê-lo.** Protótipos são "enganosamente atraentes" para quem não sabe que são protótipos; patrocinadores tentarão implantá-lo. Se o ambiente não suportar essa clareza, **use código rastreador**.
- O rastreador dá: usuários vendo algo cedo, esqueleto para os desenvolvedores, **plataforma de integração diária**, algo para demonstrar, e senso real de progresso (evita o módulo "95% pronto" há seis semanas).

Brooks chega ao mesmo lugar: *"planeje jogar um fora; você vai, de qualquer maneira"* — e, na revisão de 20 anos, **corrige a si mesmo**: a metáfora certa não é construir e descartar, é **crescer** (desenvolvimento incremental de Mills: o sistema roda desde o primeiro dia, mesmo só chamando stubs, e vai sendo preenchido). Arbitragem em §11.2.

### 2.4 Histórias de usuário — o formato ágil do requisito

Antes do formato, a definição que a maioria dos times perde: **história de usuário = Cartão + Conversas + Confirmação** (os "3 C", Jeffries).

| Parte | O que é | Quem produz |
|---|---|---|
| **Cartão** | Poucas sentenças, na linguagem do cliente, com uma funcionalidade desejada. É um **lembrete**, não uma especificação. | Cliente / PO |
| **Conversas** | O detalhamento verbal ao longo da iteração. Substitui deliberadamente a especificação textual completa — por isso o cliente precisa estar disponível **todos os dias**. | Cliente + devs |
| **Confirmação** | Os **testes de aceitação** de alto nível que o cliente usará para dizer "está pronto". Escritos cedo, no início da iteração (tradicionalmente no verso do cartão). Não são testes automatizados. | Cliente |

O contrato implícito entre as partes, que é o que faz o mecanismo funcionar: o cliente pede a história e **se compromete a estar disponível** para refiná-la; os devs se comprometem a implementá-la na iteração; e **o cliente não pode, no fim, testar com um critério diferente do que ele mesmo escreveu**. Quem critica história por "ser só duas frases" está olhando um dos três C.

**Formato:** *Como um \<papel de usuário>, eu gostaria de \<realizar algo com o sistema>.* Antes de escrever qualquer história, **liste os papéis de usuário** (usuário típico, professor, funcionário…) — é o que impede que o backlog fique enviesado para um único perfil. O **workshop de escrita de histórias** (uma sala com representantes dos principais usuários, até uma semana) é a forma de produzir a primeira leva.

**INVEST — as seis propriedades de uma boa história:**

| | Propriedade | Como falha na prática |
|---|---|---|
| **I** | **Independente** — X e Y implementáveis em qualquer ordem | cadeia de dependências que engessa a priorização |
| **N** | **Negociável** — o cartão é convite à conversa; os dois lados cedem | cartão que já traz solução técnica fechada |
| **V** | **Valor** para o negócio do cliente | "o sistema deve ser em React/Node" — **não existe história técnica** |
| **E** | **Estimável** | ninguém sabe dimensionar → falta domínio ou está grande demais |
| **S** | **Sucinta** | épicos são permitidos, mas **ficam no fim do backlog**; o topo deve caber em menos de uma semana |
| **T** | **Testável** — critério de aceitação objetivo | "o cliente não deve esperar muito" é vago; "aceita cartões destas bandeiras" é testável |

Três casos que sempre aparecem e têm resposta definida:

- **Requisito não funcional em história?** Escreva a história, mas **ela não vai para o backlog do produto**: use-a para reforçar os **critérios de conclusão** (*done criteria*) de todas as histórias — revisão de código focada em desempenho, teste de desempenho antes da release. Requisito não funcional é preocupação de **todas** as iterações, não de uma.
- **História para estudar uma tecnologia?** Não — história tem que ter valor para o cliente e ser escrita por ele. Estudo é **tarefa**, e tarefas de aquisição de conhecimento chamam-se ***spikes***.
- **Gold plating**: os devs sofisticam a implementação por conta própria, sem pedido do cliente ("cobrir a história com camadas de ouro"). O antídoto estrutural é justamente **o cliente escrever os testes de aceitação**.

**Estimativa:** *story points* medem **tamanho relativo**, não horas — a história mais simples vale 1, uma cerca de duas vezes mais complexa vale 2, e assim por diante, normalmente numa escala de Fibonacci (1, 2, 3, 5, 8, 13). A pergunta que calibra a escala: *o esforço desta tarefa de 8 equivale ao de uma de 5 mais uma de 3?* A **velocidade** (pontos por iteração) sai da medição das iterações passadas e serve de **teto para a priorização do cliente** — nunca de meta de produtividade (§11.12). **Planning poker**: cada dev estima em silêncio, todos revelam ao mesmo tempo, e **a divergência é o produto** — os extremos explicam seu raciocínio e revota-se até convergir. Mesma lógica anti-ancoragem do risk storming (§10.4).

### 2.5 Casos de uso — quando o requisito precisa de fluxo

Caso de uso é **documento textual** de especificação, mais detalhado que a história, escrito **pelos desenvolvedores** (a partir de entrevistas) mas legível e validável pelos usuários antes do design. Mike Cohn resume a diferença de propósito: **caso de uso documenta um acordo** entre cliente e time; **história facilita o planejamento da iteração e lembra que há uma conversa a ter**.

**Estrutura:**

```
Nome (verbo no infinitivo)
Ator: quem inicia (humano, sistema ou hardware — sempre externo)
Fluxo normal:   1..n passos do "caminho feliz"
Extensões:      2a, 3a, 5a, 5b… — alternativas e erros, numeradas pelo passo de origem
[opcional: propósito, pré-condições, pós-condições, casos de uso relacionados]
```

Inclusão de outro caso de uso: escreva o nome **sublinhado** dentro de um passo; a semântica é a de uma macro — todos os passos do caso incluído executam antes de prosseguir.

**Regras de escrita que separam caso de uso útil de pseudocódigo:**

- **Evite `se` no fluxo normal.** Decisão entre dois comportamentos normais vira **extensão**. Por isso, em casos de uso reais, as extensões costumam ter mais passos que o fluxo normal.
- **Máximo ~9 passos no fluxo normal** (Cockburn): *"raramente encontro um caso de uso bem escrito com mais de nove passos no cenário principal"*. Passou disso, quebre em dois ou agrupe passos ("informa login e senha").
- **Linguagem simples, ator como sujeito + verbo**: "o cliente insere o cartão"; quando a ação é do sistema, "o sistema valida o cartão".
- **Não é algoritmo.** Nada de `repita até`; escreva "o cliente pesquisa o catálogo até encontrar o produto".
- **Não trate de tecnologia, design ou interface.** "O cliente pressiona o botão verde" é decisão de UI, não requisito.
- **Nada de CRUD trivial** (Cadastrar/Recuperar/Atualizar/Deletar Professor). No máximo um "Gerenciar Professor" com uma ou duas sentenças.
- **Padronize o vocabulário** — mantenha o glossário (§2.1): projeto em que usuários e devs chamam a mesma coisa por nomes diferentes (ou coisas diferentes pelo mesmo nome) raramente dá certo.

**Diagrama de casos de uso** (UML) é apenas um **índice gráfico**: atores (bonecos), casos (elipses), a fronteira do sistema (retângulo) e as relações de participação/inclusão. Larman e Fowler são explícitos: **o valor está no texto**, não no diagrama — modelar casos de uso é escrever, não desenhar. Coloque a energia no texto.

**Critério de escolha:**

| Use **história** quando | Use **caso de uso** quando |
|---|---|
| Requisitos mudam e o sistema não é crítico | Requisitos estáveis, ou processo dirigido a planos |
| Há representante do cliente disponível todo dia | A comunicação é escrita e assíncrona |
| O valor está na conversa | O valor está no **acordo registrado** — contrato, auditoria, certificação (médico, transporte, militar) |

### 2.6 MVP — o experimento, não a versão 0.1

**Produto Mínimo Viável**: sistema funcional com **apenas o conjunto mínimo de funcionalidades necessário para testar uma hipótese de negócio**. A raiz é *Lean* (Ries, a partir da Manufatura Lean da Toyota): eliminar desperdício — e **o maior desperdício possível em software é passar anos construindo um sistema que ninguém vai usar**. Se é para falhar, falhe cedo e barato.

**Ciclo construir → medir → aprender**, produzindo *aprendizado validado*. Três desfechos possíveis:

1. **Iterar** — mais testes, mudando requisitos, interface ou mercado-alvo.
2. ***Market fit*** — hipótese confirmada; agora sim vale investir num sistema robusto.
3. **Falha** — restam **perecer** (desistir) ou **pivotar** (abandonar a visão original, novo MVP, novo mercado, preservando o aprendizado).

**MVP não é necessariamente software.** Os dois exemplos canônicos: a **Zappos** (fotos de sapatos de lojas locais numa página simples, com **todo o processamento manual** — validou que existia mercado para venda de sapatos on-line antes de qualquer automação) e o **Dropbox** (vídeo caseiro de 3 minutos que levou a lista de interessados de 5 mil para 75 mil, validando que havia demanda por sincronização automática). Um MVP real também pode ser software mínimo: o CSIndexbr começou com <200 linhas de Python e gráficos que eram planilhas do Google embutidas em HTML.

**Distinções que evitam confusão:**

- **MVP × protótipo (§2.3):** a diferença está nas três letras. Protótipo **não é necessariamente mínimo** (pode conter a interface inteira), **não é necessariamente testado com usuários finais** (pode ser demo para executivos) e **não é um produto**.
- **Qualidade de um MVP:** deve ter **a qualidade mínima para rodar o laço construir-medir-aprender** — qualquer qualidade além disso é desperdício, porque o produto pode ser descartado. **Mas** qualidade baixa demais produz **falso negativo**: o MVP hospedado num servidor que cai é invalidado por indisponibilidade, não pela hipótese. Esse é o limite inferior real.
- **Quando não usar MVP:** mercado estável e conhecido (não há hipótese a validar) e **sistemas de missão crítica** — não se constrói MVP de monitoramento de UTI (§1.2).
- **MVP não é só de startup.** Startup é qualquer iniciativa criando produto novo **sob incerteza extrema** — inclusive dentro de órgão público, ONG ou empresa grande.

**Quando nem a ideia do sistema está clara**, construa antes um protótipo via **Design Sprint** (Knapp): time-box de **cinco dias**, equipe multidisciplinar de ~sete pessoas **incluindo um tomador de decisão**, e a sequência **convergir → divergir → convergir**: seg. entender e delimitar o problema; ter. gerar alternativas livremente; qua. escolher a vencedora (**a palavra final é do decisor — não é processo democrático**); qui. prototipar (pode ser HTML estático, sem código); sex. testar com **cinco clientes reais** em sessões individuais. Serve para qualquer problema, não só MVP — por exemplo, redesenhar a interface de um sistema em produção com alta taxa de abandono.

### 2.7 Métricas de produto e testes A/B

**Métricas de vaidade × métricas acionáveis.** *Pageviews*, downloads e cadastros acumulados fazem bem ao ego e **não ajudam a decidir nada** — sobem sozinhos com o tempo. Métrica acionável é a que muda uma decisão: taxa de visitantes que fecham compra, valor por pedido, itens por compra, custo de captação. Se a métrica diz "a maioria compra um único item", a ação é concreta: incorporar (ou melhorar) recomendação.

**Métricas de funil**, por coorte: **aquisição** (visitaram) → **ativação** (criaram conta) → **retenção** (voltaram) → **receita** (compraram) → **recomendação** (indicaram).

**Teste A/B** (*split test*): duas versões idênticas exceto por um requisito mutuamente exclusivo — **versão de controle** (A, o status quo) e **versão de tratamento** (B) — liberadas **aleatoriamente** para grupos distintos de usuários reais, comparadas por uma **taxa de conversão** definida antes. É seleção de requisitos **dirigida por dados**: o perdedor é descartado.

Regras que separam teste A/B de superstição:

- **Calcule o tamanho da amostra antes** e **não pare no meio.** Encerrar no primeiro dia em que o ganho aparece é o erro mais frequente e mais grave. O teste termina **exatamente** no tamanho planejado — nem antes, nem depois.
- **Ordem de grandeza da amostra:** com taxa de conversão de 1% e ganho mínimo detectável de 10%, são necessários **~200 mil usuários por grupo** (confiança de 95%). Com conversão de 10% e ganho de 25%, caem para **~1.800 por grupo**. Ou seja: **eventos raros e ganhos pequenos exigem tráfego que a maioria dos sistemas não tem** — saber disso antes evita semanas gastas num teste que não pode concluir.
- **Rode testes A/A** (as duas versões idênticas) antes de confiar na infraestrutura: eles **deveriam falhar quase sempre**. Se um A/A "vence", há viés no sistema de experimentação — depure até a causa raiz antes de rodar qualquer A/B.
- **A/B/n** é a generalização para mais de um tratamento (dividir o tráfego em três ou mais grupos aleatórios).
- **Estatisticamente é um teste de hipótese**: H0 = "B não é melhor que A" (status quo); o nível de significância α é a probabilidade de **erro do Tipo I** (falso positivo — concluir que B é melhor sem ser). Nível de confiança = 1 − α (tipicamente 95%). Controle/tratamento vêm dos **experimentos randomizados controlados** da medicina, que são a forma cientificamente aceita de provar causalidade.

**Como as grandes empresas usam isso:** no Facebook, testes A/B substituem parte da elicitação antecipada de requisitos — e revelam usos inesperados das funcionalidades; na Netflix, **cada funcionalidade é um experimento**, e funcionalidades morrem depois de lançadas quando todos os experimentos falham; no Bing (2013) rodavam **mais de 200 experimentos simultâneos por dia**.

**Limite ético e de escopo:** o A/B escolhe entre alternativas que o time já considera aceitáveis; ele não decide se algo **deve** ser feito (§10.9). E, conceitualmente, testes A/B são a instanciação empírica do Axioma 7 e do critério de §2.2: especifique até onde só o experimento resolve — e então faça o experimento.

---

## 3. O ciclo de trabalho

```
 entender ──► esqueleto ponta a ponta ──► ciclo curto ──► destilar
  (§2)          (tracer bullet, §2.3)       (abaixo)      (§4.6, §8)
                                               │
             ┌─────────────────────────────────┴───────────────────────┐
             │ 1. teste que falha            (Martin: 3 leis do TDD)   │
             │ 2. código mínimo para passar                            │
             │ 3. refatorar com testes verdes (Fowler: dois chapéus)   │
             │ 4. integrar                   (Evans: integração contínua)│
             └─────────────────────────────────────────────────────────┘
```

**Os dois chapéus (Fowler)** — o hábito mental mais importante do laço: a cada instante você está *ou* acrescentando funcionalidade *ou* refatorando, **nunca os dois**. Ao acrescentar, não altera código preexistente. Ao refatorar, não acrescenta funcionalidade nem testes novos. Você troca de chapéu com frequência, mas sabe sempre qual está usando. Quando não sabe, é aí que os bugs entram.

**As três leis do TDD (Martin):**
1. Não escreva código de produção até ter um teste de unidade que falhe.
2. Não escreva mais de um teste de unidade do que o necessário para falhar — não compilar já é falhar.
3. Não escreva mais código de produção do que o necessário para o teste falho passar.

O efeito pretendido não é "cobertura": é impor um ciclo de ~30 segundos em que teste e produção nascem juntos, e **forçar você a pensar como cliente da sua própria interface antes de implementá-la** (Evans faz a mesma observação ao justificar INTENTION-REVEALING INTERFACES).

**Encerramento do laço (Hunt, Dica 63):** a codificação só está concluída depois que todos os testes rodam.

---

## 4. Modelagem do domínio

### 4.1 UBIQUITOUS LANGUAGE — o mecanismo, não o slogan

Evans: use o modelo como espinha dorsal de uma linguagem; comprometa o time a exercitá-la implacavelmente em toda comunicação **e no código**; use a mesma linguagem em diagramas, texto e **especialmente na fala**. Quando surgir dificuldade de expressão, **experimente formulações alternativas — cada formulação reflete um modelo alternativo** — e então refatore o código, renomeando classes, métodos e módulos.

O ponto tácito que se costuma perder: **a dificuldade de dizer uma frase em voz alta é instrumento de diagnóstico de modelo.** Frase torta, modelo torto. Por isso Evans insiste em *modelar em voz alta*.

Convergência: Hunt (Dica 17) — *programe num nível próximo ao domínio*, chegando, quando compensa, a uma minilinguagem do domínio, onde a especificação vira código executável. Martin — use nomes do domínio da solução quando houver termo técnico consagrado; caso contrário, nomes do domínio do problema.

### 4.2 MODEL-DRIVEN DESIGN e modeladores que põem a mão no código

Projete uma parte do sistema para refletir o modelo de forma **literal**, de modo que o mapeamento seja óbvio; revise o modelo para que seja implementável naturalmente. Exija **um único modelo** servindo às duas finalidades.

**HANDS-ON MODELERS:** qualquer pessoa técnica que contribua para o modelo precisa tocar o código; quem altera código precisa aprender a expressar o modelo através dele. Modelo desenhado por quem não implementa degenera em documentação morta.

### 4.3 Blocos de construção (vocabulário estrutural de responsabilidade)

- **ENTITY** — distinguida por **identidade**, não por atributos. Definição simples, focada em continuidade de ciclo de vida e identidade. Defina explicitamente o que significa "ser a mesma coisa".
- **VALUE OBJECT** — descreve característica, sem identidade; **imutável**, livremente substituível. Preferir VALUE a ENTITY sempre que possível reduz drasticamente o custo de concorrência e de raciocínio.
- **SERVICE** — operação que não pertence a nenhuma ENTITY/VALUE. Três características: (1) corresponde a conceito do domínio que não é parte natural de ENTITY/VALUE; (2) interface definida em termos de outros elementos do modelo; (3) **stateless** — qualquer cliente usa qualquer instância sem depender do histórico dela.
- **MODULE** — escolha módulos que **contem a história do sistema** e contenham conjunto coeso de conceitos. Se isso não produzir baixo acoplamento, o problema é o modelo: procure o conceito faltante que reuniria os elementos de forma significativa.
- **AGGREGATE** — fronteira de consistência com uma raiz. As sete regras:
  1. A raiz tem identidade global e é a responsável final por checar invariantes.
  2. Entidades internas têm identidade **local**, única só dentro do agregado.
  3. Nada externo pode manter referência a algo interno, exceto à raiz. Referências internas podem circular para uso **transitório** numa única operação, nunca retidas.
  4. Só raízes são obtidas diretamente por consulta ao armazenamento; o resto por travessia.
  5. Objetos internos podem referenciar **raízes** de outros agregados.
  6. Excluir a raiz remove tudo dentro da fronteira, de uma vez.
  7. Ao confirmar qualquer mudança interna, **todos** os invariantes do agregado inteiro devem estar satisfeitos.
- **FACTORY** — desloca a criação de objetos complexos e agregados para um objeto separado, que **cria o agregado inteiro de uma vez, garantindo invariantes**, sem obrigar o cliente a conhecer classes concretas.
- **REPOSITORY** — para cada tipo com acesso global, forneça a **ilusão de uma coleção em memória** de todos os objetos daquele tipo, com interface global bem conhecida, encapsulando a tecnologia de armazenamento.
- **SPECIFICATION** — regra de negócio como objeto testável e combinável, separada do objeto que avalia.

### 4.4 SUPPLE DESIGN — heurísticas de qualidade interna

- **INTENTION-REVEALING INTERFACES** — nomeie pelo **efeito e propósito**, nunca pelo meio. Nas interfaces públicas do domínio: declare relações e regras, não como são impostas; descreva eventos e ações, não como são executados; formule a equação, não o método numérico. *Faça a pergunta, não apresente a solução.*
- **SIDE-EFFECT-FREE FUNCTIONS** — máximo de lógica em funções sem efeito observável. Segregue **comandos** (que alteram estado) em operações muito simples que **não retornam informação de domínio**. Mova lógica complexa para VALUE OBJECTS imutáveis. (Mesmo princípio de *Separe a Pesquisa do Modificador* em Fowler e do *command-query separation* em Martin — três autores, um princípio.)
- **ASSERTIONS** — declare pós-condições e invariantes. Se a linguagem não suporta, **escreva testes automatizados para elas**. Busque modelos com conjuntos coerentes de conceitos, que levem o desenvolvedor a **inferir** as asserções pretendidas.
- **CONCEPTUAL CONTOURS** — decomponha nas divisões *reais* do domínio. Método: observe, através de refatorações sucessivas, quais eixos mudam e quais permanecem estáveis; esses "planos de cisalhamento" revelam o contorno conceitual.
- **STANDALONE CLASSES** — reduza o número de conceitos que é preciso ter na cabeça ao mesmo tempo.
- **CLOSURE OF OPERATIONS** — quando couber, defina operações cujo tipo de retorno é o dos argumentos. Interface de alto nível sem dependência de outros conceitos.

### 4.5 BOUNDED CONTEXT e integração

- **BOUNDED CONTEXT** — defina explicitamente o contexto em que um modelo se aplica, em termos de **organização do time**, uso em partes específicas da aplicação e manifestações físicas (base de código, esquema de banco). Modelo estritamente consistente dentro dos limites; **não se distraia com o que está fora**.
- **CONTINUOUS INTEGRATION** — funda o trabalho com frequência, com testes automatizados sinalizando fragmentação. Essencial **apenas dentro** de um contexto; a integração com vizinhos não precisa do mesmo ritmo.
- **CONTEXT MAP** — identifique cada modelo em jogo, nomeie cada contexto (nomes entram na linguagem ubíqua), descreva pontos de contato e tradução explícita. **Mapeie o terreno existente primeiro; transformações vêm depois.**

| Padrão de relação | Use quando |
|---|---|
| **SHARED KERNEL** | Dois times compartilham um subconjunto do modelo e do código, com integração e testes conjuntos. Alto custo de coordenação, alto ganho de coerência. |
| **CUSTOMER/SUPPLIER** | Dependência clara a jusante/montante e **os times podem negociar**. O time a jusante entra como cliente no planejamento do montante; testes de aceitação conjuntos entram na suíte do montante. |
| **CONFORMIST** | Você depende de um modelo a montante, sem poder de negociação, e o modelo é aceitável. Adere escravamente e elimina o custo de tradução — ao preço de se limitar às capacidades deles. |
| **ANTICORRUPTION LAYER** | O modelo do outro sistema (legado/externo) **contaminaria** o seu. Camada isolante que fala o seu modelo para dentro e o deles para fora, traduzindo nas duas direções. |
| **SEPARATE WAYS** | A integração custa mais do que vale. Declare que não há conexão e permita soluções simples e especializadas de cada lado. |
| **OPEN HOST SERVICE** | Muitos consomem seu subsistema. Publique um protocolo; para necessidades idiossincráticas de um cliente, use tradutor pontual em vez de poluir o protocolo comum. |
| **PUBLISHED LANGUAGE** | A tradução precisa de meio comum documentado; adote um padrão existente quando houver. |

### 4.6 Destilação — separar o que importa do que só precisa existir

- **CORE DOMAIN** — a parte que justifica o projeto existir. Aloque **seus melhores desenvolvedores** aqui e mantenha-os.
- **GENERIC SUBDOMAINS** — subdomínios coesos que **não são a motivação** do projeto. Extraia para módulos separados sem deixar traço das suas especificidades; dê prioridade menor; **considere soluções de prateleira ou modelos publicados**. Não coloque seus melhores no genérico — eles não ganham conhecimento de domínio ali.
- **COHESIVE MECHANISMS** — quando um mecanismo (algoritmo, formalismo) fica intrincado, separe-o num framework leve com interface reveladora de intenção. O núcleo passa a expressar **o quê**, delegando o **como**.
- **SEGREGATED CORE / ABSTRACT CORE** — refatore para separar conceitos centrais dos coadjuvantes, fortalecendo a coesão do núcleo e reduzindo seu acoplamento, mesmo que isso obrigue a separar elementos hoje muito acoplados.

**Fora de DDD:** antes de otimizar qualquer coisa — código, arquitetura, processo, alocação de pessoas — pergunte *"isto é núcleo ou é infraestrutura da vida?"*. Esforço no genérico é esforço subtraído do que diferencia o produto.

### 4.7 O caso legítimo do SMART UI

Evans documenta um anti-padrão que, **em certos contextos, é a escolha correta**: toda a lógica na interface, aplicação fatiada em telas, banco como repositório compartilhado, ferramentas visuais automatizadas.

Vantagens reais: produtividade alta e imediata em aplicações simples; desenvolvedores menos experientes produzem; requisitos mal entendidos causam dano local.
Custo: nenhuma reutilização de comportamento, nenhuma abstração do negócio, impossibilidade prática de evoluir para comportamento rico.

**Critério:** aplicações pequenas, de vida curta, regras triviais, sem expectativa de crescimento comportamental. Fora disso, é a dívida que não se paga — só se reescreve.

### 4.8 Modelos e UML — o uso que sobrevive é o esboço

§4.1–§4.7 tratam do modelo **conceitual** do domínio. Esta seção trata da **notação** com que se desenha qualquer modelo — e de quando desenhar vale a pena.

**As três formas de usar UML** (Fowler), com o veredito de cada uma:

| Uso | O que é | Situação hoje |
|---|---|---|
| **Blueprint** | Modelos completos e detalhados produzidos por analistas em ferramentas CASE e repassados a programadores para codificar. É o uso original, dos anos 90, casado com Waterfall e o UP. | Praticamente extinto: não há mais *big design up front*, e o modelo detalhado envelhece mais rápido do que se atualiza. |
| **Linguagem de programação** (MDD) | Gerar código a partir dos modelos, eliminando a fase de codificação. Foi por causa dessa ambição que a UML inchou. | Não pegou fora de nichos. A complexidade extra ficou; o benefício, não. |
| **Esboço (*sketch*)** | Diagramas **leves, informais e parciais** de partes do sistema, para comunicação entre desenvolvedores. Desenhados em quadro, fotografados, apagados. | **É o uso vivo, e o único que esta skill recomenda.** |

**Os dois momentos do esboço:**
- **Engenharia avante** — antes de codificar: esboçar as classes e relações que a história vai exigir, para validar a proposta antes de escrever código.
- **Engenharia reversa** — sobre código existente: explicar a alguém como uma funcionalidade já implementada funciona, sem percorrer linha a linha.

**Por que usar UML e não uma notação própria:** o esboço evita dois extremos — o rigor caro e inútil do blueprint e a notação *ad hoc* cuja semântica ninguém compartilha. Some-se que livros, tutoriais e documentação de frameworks usam UML: quem não a lê perde explicação alheia (inclusive a de padrões de projeto, §5.4).

Dado empírico que calibra a expectativa (survey com 394 desenvolvedores, 32 países): 39% haviam feito um esboço na semana anterior; **58% arquivaram o último esboço** (42% digitalmente) — ou seja, o esboço carrega informação que se julga valiosa; 40% em papel, 39% no computador, 18% em quadro; usos principais: arquitetura (52%), projeto de nova funcionalidade (48%), explicar tarefa a outro dev (46%), analisar requisitos (45%). E **48% dos esboços continham algum elemento de UML, mas só 9% eram integralmente UML** — o que descreve exatamente o regime correto: UML **parcial**, misturada com o que for necessário.

**Estáticos × dinâmicos** — a escolha do diagrama segue a pergunta:

| Se a pergunta é… | Use |
|---|---|
| Como o sistema é **estruturado**? Que classes, atributos, relações existem? | **Diagrama de classes** (estático) |
| Qual a estrutura em **alto nível**, em grupos e suas dependências? | **Diagrama de pacotes** (estático) |
| O que **acontece em execução**, nesta funcionalidade, nesta ordem? | **Diagrama de sequência** (dinâmico) |
| Qual o **fluxo do processo**, com decisões e paralelismo? | **Diagrama de atividades** (dinâmico) |
| Qual o **escopo** do sistema e quem interage com ele? | **Diagrama de casos de uso** (§2.5 — índice gráfico, o valor está no texto) |

**Diagrama de classes — o vocabulário mínimo (os 20% que cobrem 80% do uso):**

- Retângulo com três compartimentos: **nome** (negrito), **atributos**, **métodos**; `-` privado, `+` público, com tipos.
- **Associação** (seta cheia): A tem atributo do tipo B; o nome do atributo vai na ponta da seta. Associação **unidirecional** é o padrão — e é uma decisão de projeto, não um detalhe de desenho: navegar nos dois sentidos custa um atributo a mais e acoplamento a mais (§5.2).
- **Multiplicidade** (`1`, `0..1`, `*`) nas pontas. Qual é a correta? **Depende dos requisitos** — quem responde é o usuário, não o modelador. O diagrama apenas registra a resposta.
- **Herança**: seta com ponta vazia da subclasse para a base.
- **Dependência** (seta tracejada): A **usa** B sem tê-lo como atributo nem herdar dele — parâmetro, variável local, exceção lançada. É o vínculo **mais fraco** dos três, e é isso que o torna a forma preferível de acoplamento quando há escolha (§5.2, §11.3).

**Diagrama de pacotes**: só nome do pacote e **setas tracejadas** entre pacotes. Duas convenções que mudam a leitura: a seta **não** informa *quantas* classes dependem (uma única classe de P1 usando uma de P2 já cria a dependência P1→P2), e **há um único tipo de seta** — associação, herança e dependência colapsam na mesma notação. É por isso que o diagrama de pacotes é o instrumento certo para **enxergar ciclos e violações de camadas** (§5.9, §5.12) e o instrumento errado para julgar a intensidade do acoplamento.

**Diagrama de sequência**: objetos (não classes) e a ordem das chamadas num cenário concreto. Melhor uso: explicar *um* fluxo relevante — autenticação, checkout, saque no caixa eletrônico — não o sistema inteiro.

**Diagrama de atividades**: processo ou fluxo de execução com nós de ação, decisão e fluxos. Diferença prática para **fluxograma**: atividades suportam **concorrência** (bifurcação/junção); fluxogramas são sequenciais. Para processos de negócio que analistas não técnicos precisam ler e validar, **BPMN** é a notação mais adequada.

**Regra de uso final:** modelos são **escritos por desenvolvedores, para desenvolvedores** — é a diferença essencial em relação a requisitos (§2.5), que são escritos por desenvolvedores mas para serem validados por usuários. Se o diagrama não vai ser lido por ninguém além de quem o desenhou, ele não é comunicação: é cerimônia (§11.11).

---

## 5. Projeto e arquitetura

### 5.1 As duas forças: duplicação e ortogonalidade

- **DRY / NSR** — cada peça de conhecimento deve ter representação única, não ambígua e definitiva. Reduz duplicação *dentro* do sistema.
- **Ortogonalidade** — mudar uma coisa não deve afetar coisas não relacionadas. Reduz interdependência *entre* componentes.

**Os quatro tipos de duplicação** (é esta taxonomia que torna DRY acionável em vez de dogmático):

1. **Imposta** — o ambiente parece exigir (headers vs. implementação, esquema vs. classe, documentação vs. código, múltiplas plataformas). Tratamento: **gere a partir de fonte única**, com processo **ativo** (roda a cada build), não conversão feita uma vez. Se inevitável, prefira a forma que **falha no build** ao divergir.
2. **Inadvertida** — erro de modelagem. Ex.: `Caminhão` tem motorista e `RotaDeEntrega` também — qual mudar quando o motorista troca? Tratamento: **normalize contra o modelo de negócio**, ou introduza o terceiro objeto que reúne os conceitos.
3. **Impaciente** — copiar e colar porque é mais rápido agora. Sempre mais caro depois.
4. **Entre desenvolvedores** — a mais difícil. Comunicação ativa, um "bibliotecário" do projeto, visibilidade do que já existe.

**Como manter ortogonalidade:**
- Módulos tímidos, que não revelam nada desnecessário nem dependem da implementação alheia.
- **Evite dados globais.** Passe contexto explicitamente. Cuidado com singletons — variáveis globais disfarçadas, criam acoplamento invisível.
- **Evite funções semelhantes.** Funções que compartilham começo e fim mas diferem no miolo são sintoma estrutural — extraia a variação (Strategy).
- **Teste como termômetro:** se você precisa envolver metade do sistema para compilar um teste unitário, achou um módulo não desacoplado. Construir o teste unitário *é* um teste de ortogonalidade.
- **Bug como termômetro:** o conserto tocou um módulo ou se espalhou? Corrigiu tudo, ou fez surgir problemas em outro lugar?

### 5.2 Acoplamento, coesão e conascência — a régua

**Coesão** (Richards & Ford, melhor→pior): funcional → sequencial → comunicacional → procedural → temporal → lógica → **coincidental** (juntos só por estarem no mesmo arquivo; a pior). Os autores admitem que **coesão é métrica menos precisa que acoplamento** e que o grau aceitável é decisão do arquiteto — decisão que eles demonstram como análise de trade-off explícita ("estas são as duas únicas operações de X? espera-se que Y cresça? Y precisa de tanto conhecimento de X que separá-los exigiria alto acoplamento?").

**Acoplamento**: aferente (entrada) e eferente (saída). Derivadas: **abstração** = abstratos/(abstratos+concretos); **instabilidade** = eferente/(aferente+eferente); **distância da sequência principal**, que penaliza tanto "abstrato e inútil" quanto "concreto e rígido".

**Conascência** (Page-Jones, resgatada por Weirich) — a régua mais fina:

> Dois componentes são conascentes se uma mudança em um exige mudança no outro para manter a correção do sistema.

*Estática* (visível no fonte), fraca→forte: **Nome** → **Tipo** → **Significado/Convenção** → **Posição** → **Algoritmo**.
*Dinâmica* (só em execução; sempre pior, porque não há boa ferramenta de detecção): **Execução** (a ordem importa) → **Tempo** (o instante importa — condições de corrida) → **Valores** (valores que mudam juntos — transações distribuídas) → **Identidade** (devem referenciar a mesma entidade).

Três propriedades que a tornam ferramenta de decisão:
- **Força** — quanto mais fácil refatorar, mais fraca. **Prefira sempre estática a dinâmica**, porque a estática é detectável e refatorável com ferramentas.
- **Localidade** — a mesma forma é aceitável dentro de um módulo e perigosa entre módulos. *"As formas mais fortes de conascência no mesmo módulo representam menos cheiro do que a mesma conascência afastada."*
- **Grau** — quantos elementos ela atinge.

Diretrizes:
1. Minimize a conascência geral dividindo o sistema em elementos encapsulados.
2. Minimize a que **cruza** limites de encapsulamento.
3. Maximize a que fica **dentro** dos limites.
4. **Regra do Grau:** converta formas fortes em fracas (número mágico → constante nomeada converte conascência de significado em conascência de nome).
5. **Regra da Localidade:** conforme a distância aumenta, use formas mais fracas.

### 5.3 Princípios de reutilização e variação (GoF, generalizados)

1. **"Programe para uma interface, não para uma implementação."** Não declare variáveis como classes concretas; prenda-se à interface. Clientes desconhecem tipos concretos e as classes que os implementam — é isso que reduz dependência entre subsistemas. Onde a linguagem não tem classes abstratas, o princípio persiste como "dependa do contrato, não do fornecedor".
2. **"Prefira a composição de objetos à herança de classe."** Herança é reutilização de **caixa branca**: estática, simples, mas expõe a implementação do ancestral — *"herança viola o encapsulamento"* —, não muda em execução, e amarra a subclasse a mudanças da mãe. Composição é **caixa preta**: exige interfaces bem projetadas, preserva o encapsulamento, permite troca em execução, e mantém cada classe focada em **uma única tarefa**.
   **Contrapartida que os autores registram:** projetos compostos têm mais objetos (embora menos classes) e o comportamento passa a depender de inter-relações em vez de estar declarado numa classe — software altamente parametrizado é mais difícil de entender. *Ineficiências humanas importam mais, a longo prazo, do que ineficiências de execução.*
3. **Delegação** torna composição tão poderosa quanto herança (o receptor passa a si mesmo ao delegado). Mas *"delegação é boa escolha somente quando simplifica mais do que complica"*, e funciona melhor em formas estilizadas — isto é, **em padrões catalogados**.

**Distinção fundamental:** herança de **classe** (compartilhar implementação) ≠ herança de **interface**/subtipificação (poder ser usado no lugar de). Muitas linguagens confundem; você não deve.

### 5.4 As oito causas de reprojeto — o gatilho para usar padrões

| Causa | O que fazer |
|---|---|
| 1. Criar objeto especificando classe concreta | Crie indiretamente (padrões de criação) |
| 2. Dependência de operações específicas | Evite solicitações hard-coded; encapsule a solicitação |
| 3. Dependência de plataforma de HW/SW | Isole atrás de abstração |
| 4. Dependência de representação/implementação | Oculte a representação do cliente |
| 5. Dependências algorítmicas | Isole algoritmos que provavelmente mudarão |
| 6. Acoplamento forte | Acoplamento abstrato e projeto em camadas |
| 7. Estender funcionalidade por subclasses | Prefira composição/delegação; subclasse custa inicialização, exige entender a mãe, e explode em número de classes |
| 8. Incapacidade de alterar classes (fonte indisponível, muitas subclasses) | Adaptação externa (adaptar, decorar, visitar) |

**Duas abordagens complementares para escolher um padrão:**
- Olhar **causas de reprojeto** (o que forçará mudança).
- Olhar **o que deve poder variar** — *"encapsule o conceito que varia"*. É o inverso, e o mais poderoso: em vez de perguntar o que vai quebrar, pergunte o que você quer poder trocar sem reprojetar.

**Como aplicar um padrão:** (1) leia-o inteiro, atenção especial a *Aplicabilidade* e *Consequências*; (2) estude Estrutura, Participantes, Colaborações; (3) veja o exemplo de código; (4) **escolha nomes dos participantes que façam sentido no seu domínio** — incorporar o nome do papel torna o padrão explícito (`LayoutStrategy`, não `Strategy`); (5) defina as classes e ajuste as existentes.

**Por tipo de software:**
- *Aplicação*: prioridade em reusabilidade interna, manutenibilidade, extensibilidade. Padrões que reduzem dependência dão o maior retorno.
- *Toolkit*: mais difícil, porque você não conhece as aplicações que o usarão — evite suposições que limitem flexibilidade. Ênfase em reutilização de **código**.
- *Framework*: dita a arquitetura da aplicação e captura decisões comuns ao domínio; ênfase em reutilização de **projeto** e inversão de controle (você escreve o código que ele chama). O mais difícil dos três — e o que mais precisa de padrões.

### 5.5 Modularidade e componentes

- **Modularidade é princípio organizacional, não estético.** Sistema planejado sem atenção a ela degrada de forma previsível.
- **Particionamento técnico vs. por domínio.** Agrupar por camada técnica vs. por área do negócio. O particionamento por domínio alinha a estrutura do código à estrutura das mudanças — e mudanças chegam por domínio, não por camada. O técnico é preferível quando a variação real é técnica (ex.: múltiplos protocolos sobre a mesma lógica) ou quando a organização é estruturada por especialidade.
- **Armadilha da entidade** (anti-padrão): derivar componentes mecanicamente das entidades do modelo de dados. Indica **ausência de análise real** e produz componentes que não correspondem a nada que o sistema faça. Alternativas: identificar por **fluxo de trabalho** ou por **ator/ações**.
- **Isomorfismo domínio/arquitetura**: a topologia do estilo deve espelhar a forma do problema. Problema com plugins pede microkernel; transformações sequenciais pedem pipeline; eventos independentes pedem arquitetura orientada a eventos.

### 5.6 Escolher estilo arquitetural

Procedimento: **caracterize o problema → derive as características arquiteturais essenciais → escolha particionamento de dados e estilo de comunicação → escolha o estilo que melhor suporta essas características → registre por quê.**

> **"Nunca mire na melhor arquitetura, mas na arquitetura menos pior."**

Características **em excesso** levam a soluções genéricas que tentam resolver todo problema de negócio — e essas arquiteturas raramente funcionam, porque o design fica intratável. **Limite deliberadamente o número de características suportadas.** Corolário: torne a arquitetura o mais iterativa possível, para se estressar menos com acertar de primeira.

Fatores de escolha, por peso prático: arquitetura de dados (como os dados são particionados) → características operacionais exigidas → capacidade e habilidade do time → estilo de comunicação (síncrono/assíncrono) → topologia.

Antes de distribuir, considere as **falácias da computação distribuída**: a rede é confiável; a latência é zero; a largura de banda é infinita; a rede é segura; a topologia não muda; existe um administrador; o custo de transporte é zero; a rede é homogênea.

**Quantum da arquitetura** — componente implantável independentemente, com alto acoplamento funcional e um contexto de dados sincrônico — é a unidade real de análise: características arquiteturais são propriedades **do quantum**, não do "sistema" em abstrato. Duas partes do sistema podem legitimamente ter requisitos de disponibilidade e escalabilidade completamente diferentes.

### 5.7 Decidir e registrar decisões

**Os três anti-padrões de decisão, que se encadeiam:**

1. **Cobertura dos Ativos** — evitar/adiar a decisão por medo de errar. Cura: (a) espere até o **último momento responsável** — informação suficiente para justificar, sem atrasar as equipes nem cair em paralisia de análise; (b) **colabore continuamente com quem implementa**, porque é impossível conhecer todos os detalhes das tecnologias, e é a equipe que descobre cedo se a decisão é inviável.
2. **Feitiço do Tempo** — a decisão foi tomada mas a justificativa não foi dada, então a discussão se repete indefinidamente. Cura: **justifique sempre em duas dimensões, técnica e de negócio.**
3. **Arquitetura Baseada em E-mail** — a decisão existe mas se perde. Cura: local único e conhecido.

**ADR (Architecture Decision Record)** — arquivo curto (1–2 páginas): **Título** (numerado sequencialmente, descritivo, sem ambiguidade), **Status** (Proposto / Aceito / Substituído), **Contexto**, **Decisão** (onde entra a justificativa), **Consequências** (trade-offs aceitos e, se não houver seção própria, alternativas descartadas), e opcionalmente **Conformidade** e **Notas**.

Um bom ADR responde: o que estava em jogo, o que foi decidido, **por quê**, o que se perdeu ao decidir assim, e como saberemos se a decisão foi respeitada.

### 5.8 Governança executável: funções de aptidão

> **Função de aptidão da arquitetura: qualquer mecanismo que forneça avaliação objetiva da integridade de alguma característica da arquitetura.**

O ponto é "**qualquer mecanismo**": não é framework a instalar, é uma **perspectiva nova sobre ferramentas que você já tem** — teste de performance, verificação de ciclos de dependência, teste de contrato, checagem de camadas, complexidade ciclomática, distância da sequência principal. O que muda é o *status*: passam a rodar no build e a falhar a build.

Regra de adoção: **garanta que o time entenda a finalidade da função antes de impô-la**, ou vira burocracia contornada.

Fecha o ciclo com §2.1: característica arquitetural que você não consegue medir não pode ser governada — e, na prática, não existe. Mensurabilidade separa característica real de aspiração.

### 5.9 Reversibilidade e camadas

Hunt (Dica 14): **"não há decisões definitivas."** Decisões são escritas na areia, não esculpidas em pedra. Os mecanismos que compram reversibilidade são os já recomendados por outros motivos: DRY, desacoplamento, metadados, abstração de fornecedores atrás de interface própria. O erro não é escolher errado — é **assumir que a escolha é irrevogável e não se preparar para a contingência**.

Evans dá a forma estrutural (**LAYERED ARCHITECTURE**): particione em camadas; cada camada é coesa e depende **apenas das de baixo**; acoplamento fraco com as de cima; **concentre todo o código do modelo de domínio numa camada** e isole-o de interface, aplicação e infraestrutura. Objetos de domínio, livres de se exibir, se armazenar e gerenciar tarefas de aplicação, podem se concentrar em expressar o modelo.

Cuidados (Richards & Ford): distinga camada **aberta** de **fechada** deliberadamente; use camadas de isolamento onde a volatilidade externa é alta; vigie o anti-padrão *sinkhole*, em que a maioria das requisições apenas atravessa camadas sem lógica — se boa parte do fluxo é passagem pura, a arquitetura em camadas paga custo sem entregar benefício.

### 5.10 Concorrência, tempo e serviços

- **Analise o fluxo de trabalho para encontrar concorrência** (Dica 39). Boa parte do que se escreve sequencialmente é sequencial por hábito, não por dependência real.
- **Projete usando serviços** (Dica 40) — objetos independentes atrás de interfaces consistentes, em vez de componentes que assumem quem os chama.
- **Projete sempre pensando na concorrência** (Dica 41), mesmo com alvo single-threaded: código que assume "eu sou o único" é caríssimo de converter depois.
- **Separe visualizações de modelos** (Dica 42) e use quadros-negros/eventos (Dica 43) para coordenar fluxos sem acoplar produtores a consumidores.

Martin acrescenta a contenção: **as threads devem ser as mais independentes possível** — divida os dados em subsistemas independentes; mantenha o código concorrente separado do resto; e lembre que o comportamento errado sob concorrência raramente é reproduzível, o que faz de revisão e design a única defesa real.

### 5.11 Padrões arquiteturais concretos — camadas, três camadas, MVC, SPA

§5.6 dá o **procedimento** de escolha de estilo. Esta seção dá o **vocabulário concreto** dos padrões que dominam sistemas corporativos e web, na leitura de Valente.

**Duas definições de arquitetura, ambas úteis:**
1. **Projeto em alto nível** — o foco deixa de ser classes e passa a pacotes, componentes, módulos, camadas ou serviços. Critério de inclusão que evita listar tudo: **o módulo tem que ser relevante para os objetivos do sistema**. Persistência é arquitetural num sistema de informação (o objetivo é persistir dados de processos de negócio) e **não** é arquitetural num sistema de diagnóstico por IA, onde é acessória.
2. **O conjunto das decisões de projeto mais importantes** — aquelas que, uma vez tomadas, dificilmente se revertem: linguagem, banco de dados, particionamento. Essa definição é mais ampla e é a que conecta com M1 (custo de reversão, §11) e com ADR (§5.7).

**Advertência histórica que vale como regra geral** (debate Tanenbaum–Torvalds, 1992: Linux monolítico × microkernel): decisões arquiteturais não são apenas caras de reverter — **muitas levam anos até que seus efeitos negativos apareçam**. Ken Thompson, na época: *"é mais fácil implementar um sistema operacional com kernel monolítico; mas é também mais fácil que ele vire uma bagunça à medida que é modificado"*. Em 2009 Torvalds admitiu publicamente que o kernel havia ficado "grande e inchado". Corolário operacional: **a ausência de dor hoje não é evidência de que a decisão foi boa** — por isso funções de aptidão (§5.8) valem mais que impressão.

#### Arquitetura em camadas

Classes agrupadas em camadas hierárquicas; **a camada *n* só usa serviços da camada *n−1*** (chamar métodos, instanciar, estender, declarar parâmetro, lançar exceção). Exemplo canônico: pilha de rede (HTTP → TCP → IP → Ethernet). Primeira proposta conhecida: Dijkstra, sistema THE, 1968 — que já concluía que o benefício **cresce com o porte do projeto**.

Vantagens concretas, na ordem em que aparecem: particiona a complexidade; **disciplina as dependências**; facilita **trocar uma camada** (TCP→UDP); permite **reúso da camada inferior por várias superiores** (TCP servindo HTTP, SMTP, DHCP). Cuidados em §5.9 (camada aberta × fechada, anti-padrão *sinkhole*).

#### Três camadas (e duas)

| Camada | Responsabilidade | Onde roda |
|---|---|---|
| **Interface / apresentação** | exibição e captura de eventos (cliques, formulários) | máquina do cliente |
| **Lógica de negócio / aplicação** | regras do negócio ("nota entre 0 e o valor da avaliação"; "avisar alunos por e-mail após lançamento") | servidor de aplicação |
| **Banco de dados** | persistência | servidor de dados |

Normalmente é **arquitetura distribuída**. A camada de aplicação costuma ter uma **fachada** (facilitar acesso pelos clientes, §5.4) e um **módulo de persistência** (isolar o banco dos demais módulos). **Duas camadas** = interface + aplicação juntas no cliente, com o banco à parte; a desvantagem é jogar todo o processamento no cliente.

#### MVC

Proposto no fim dos anos 70 e usado no Smalltalk-80, para **interfaces gráficas**:

- **Visão**: apresentação (janelas, botões, menus).
- **Controladoras**: tratam eventos de entrada e, em resposta, pedem alteração ao Modelo **ou** à Visão.
- **Modelo**: dados e lógica do domínio. **Classes de Modelo não conhecem nem dependem de Visão e Controladoras** — a dependência é de mão única.

Na prática, a fronteira Visão/Controlador é difusa (nem a maioria das versões de Smalltalk a separava). Leitura mais útil: **MVC = (Visão + Controladoras) + Modelo = Interface Gráfica + Modelo**, com a interface funcionando como **observadora** do modelo (§5.4, padrão Observador).

Benefícios: **especialização do trabalho** (front-end × domínio); **várias visões sobre o mesmo modelo** (o mesmo par hora/minuto como relógio analógico e digital); e **testabilidade** — objetos não visuais são muito mais fáceis de testar (§7.8), o que faz de MVC uma decisão de teste tanto quanto de interface. Fowler e Beck resumem: *o coração e a parte mais preciosa de MVC é a separação entre código de interface e lógica de domínio*.

**MVC × três camadas — a confusão tem origem histórica:**
- MVC (anos 70) resolvia **interface gráfica**; podia ser usado *dentro* da camada de interface de um sistema três camadas (anos 90).
- Nos anos 2000, frameworks web (Spring, Rails, Django, CakePHP) chamaram-se "MVC" adaptando o termo: **visão** = páginas HTML, **controladoras** = processam a requisição e geram nova visão, **modelo** = persiste no banco. Esse **MVC Web** lembra muito mais três camadas do que o MVC clássico.
- Resposta correta quando alguém pergunta a diferença: existem **duas vertentes** — a clássica (Smalltalk) e a web — e o termo "MVC" sozinho não diz qual está em jogo. Enuncie a vertente antes de discutir.

#### Single Page Applications

Na aplicação web tradicional, cada evento vai ao servidor, que devolve uma página nova — daí a baixa responsividade. Numa **SPA**, o navegador carrega de uma vez HTML, CSS e JavaScript, e a aplicação passa a se parecer com desktop (GMail é o exemplo canônico). Continua havendo servidor, mas a comunicação é **assíncrona**. Arquiteturalmente a SPA **se parece com MVC**: interface (visão + controle) no HTML, modelo em JavaScript.

Trade-off a declarar antes de adotar (§5.6): SPA compra responsividade pagando com **complexidade de estado no cliente**, carga inicial maior, SEO e acessibilidade mais trabalhosos, e duplicação de regras entre cliente e servidor.

#### Onde ficam os demais estilos

Microserviços, arquiteturas orientadas a mensagens (filas), publish/subscribe, microkernel, pipes & filtros, cliente/servidor e peer-to-peer, além do anti-padrão **big ball of mud**, estão tratados em §5.5, §5.6, §5.9, §5.10 e §12 pela via de Richards & Ford — inclusive quantum arquitetural, falácias da computação distribuída e o critério para não distribuir. A pergunta que precede qualquer um deles continua sendo a de §5.6: **quais características arquiteturais o problema exige, e qual estilo as suporta com o menor custo de reversão.**

### 5.12 Métricas de código fonte — quantificar o que §5.2 descreve

§5.2 dá os conceitos (coesão, acoplamento, conascência); esta seção dá os **números**, e principalmente **o que eles não medem**.

Ressalva antes de tudo, porque ela decide o uso correto: monitorar projeto por métricas **não é prática dominante hoje**, por dois motivos legítimos — coesão e acoplamento têm componente **subjetiva**, e **a interpretação depende do contexto**. Uma faixa aceitável num sistema não é aceitável em outro domínio, e nem entre classes do mesmo sistema. Métrica de código é **detector de suspeita**, nunca veredito.

| Propriedade | Métrica | Cálculo | Leitura |
|---|---|---|---|
| **Tamanho** | **LOC** (+ nº de métodos, atributos, classes, pacotes) | linhas de código — **declare sempre se contou comentários e linhas em branco** | dá ordem de grandeza, nada mais |
| **Coesão** | **LCOM** (*Lack of Cohesion Between Methods*, Chidamber & Kemerer) | nº de pares de métodos da classe **sem nenhum atributo em comum** | **mede falta** de coesão: maior = pior. Ignora construtores e getters/setters. Diga qual versão usou (LCOM1, LCOM2…) |
| **Acoplamento** | **CBO** (*Coupling Between Objects*) | nº de classes das quais A depende: chama método, acessa atributo público, herda, declara variável/parâmetro/retorno, captura ou lança exceção, instancia | **não distingue dependência estável de instável** — depender de `String` conta igual a depender da classe mais volátil do sistema |
| **Complexidade** | **Complexidade ciclomática (CC)**, McCabe 1976 | **nº de comandos de decisão + 1** (`if`, `while`, `for`, `case`…) | mínimo 1. McCabe sugere **10 como limite superior razoável — "mas não mágico"** |

**Regra que governa todas elas — a mesma de §5.8 e do Axioma 9:** métrica **não é meta**. LOC como meta produz código duplicado; cobertura como meta produz teste vazio (§7.6); CC como meta produz condição escondida em outro método. Ken Thompson: *"um dos dias mais produtivos da minha vida foi quando deletei 1.000 linhas de código"* — e LOC **não mede produtividade**: 5 KLOC não valem cinco vezes 1 KLOC.

**Uso legítimo, em ordem de valor:**
1. Como **função de aptidão** (§5.8): quebrar o build quando CC de um método novo passa do limite acordado, ou quando surge ciclo de dependência entre pacotes. O valor está em *falhar automaticamente*, não no número.
2. Como **triagem** para revisão e refatoração: a distribuição dessas métricas em qualquer sistema real é fortemente assimétrica — poucas classes concentram os extremos. Ordene por LCOM/CBO/CC e olhe **a cauda**, não a média.
3. Como **evidência num argumento**, para tirar "esse código está ruim" do terreno da opinião.

**Complemento a §5.2 — acoplamento estrutural × evolutivo:**

- **Acoplamento estrutural**: A tem referência explícita a B no código. **Pode ser aceitável ou ruim, dependendo da estabilidade da interface de B.** Depender de uma interface estável e bem projetada é barato.
- **Acoplamento evolutivo (ou lógico)**: mudanças em B **tendem a se propagar** para A, sem que exista referência explícita — A lê um arquivo que B grava, A assume um formato, uma ordem, um efeito colateral. **É sempre ruim**, e é o pior caso justamente porque **nenhuma ferramenta o detecta e nenhum compilador o quebra**.

Consequência prática que inverte a intuição: um método `A.f(B b)` que declara parâmetro do tipo B pode ter acoplamento **melhor** do que um A que não menciona B em lugar nenhum mas depende do formato interno de um arquivo dele. **Contar dependências não é medir acoplamento** — por isso CBO é indício, e conascência (§5.2) é o critério.

---

## 6. Implementação

### 6.1 Nomes

**Um nome deve responder por que a coisa existe, o que faz e como é usada; se precisa de comentário para isso, o nome falhou.**

- **Revele o propósito.** `int d;` com comentário "tempo decorrido em dias" é derrota; `elapsedTimeInDays` é vitória. *"Cuide de seus nomes e troque-os quando encontrar melhores."*
- **O problema quase nunca é a complexidade do código, é o contexto implícito.** O exemplo canônico de Martin (`getThem()` → `getFlaggedCells()`) não muda um único operador: muda só nomes, e o código passa de ilegível a óbvio. **Renomear é a refatoração de maior retorno por unidade de risco.**
- **Evite informação errada.** Não chame de `accountList` o que não é lista. Cuidado com nomes quase idênticos que diferem no meio.
- **Faça distinções significativas.** `Product`/`ProductInfo`/`ProductData` não distinguem nada; `getActiveAccount()`, `getActiveAccounts()`, `getActiveAccountInfo()` são armadilha. Palavras ruidosas (`variable`, `table`, `Info`, `Data`, `Object`, `Manager`, `Processor`) não carregam informação.
- **Use nomes pronunciáveis e buscáveis.** Programação é atividade social: se não consegue pronunciar, não consegue discutir. E **o tamanho do nome deve ser proporcional ao tamanho do escopo**.
- **Evite codificações** (notação húngara, prefixos de membro, `I` de interface). Tipos modernos são verificados pelo compilador e classes pequenas tornam a declaração visível. Se for preciso codificar, **codifique a implementação** (`ShapeFactoryImpl`), não a interface — o cliente não precisa saber que recebeu uma interface.
- **Evite mapeamento mental.** *"A diferença entre um programador esperto e um profissional é que o profissional entende que clareza é fundamental."*
- **Classes são substantivos, métodos são verbos.** Acessores/modificadores/predicados com prefixo consistente.
- **Uma palavra por conceito, e um conceito por palavra.**
- **Adicione contexto significativo** (prefixo, namespace ou — melhor — uma classe) em vez de repetir contexto redundante em cada nome.

Fowler fecha a questão: métodos pequenos só funcionam com **boa nomeação**; *"se você tiver um bom nome para um método, não precisa olhar o corpo dele"*. A chave não é o tamanho — é a **distância semântica entre o que o método faz e como ele o faz**.

### 6.2 Funções

- **Pequenas.** Martin admite abertamente não ter pesquisa que sustente os números: é conclusão de quatro décadas de tentativa e erro. Ordem de grandeza: dezenas de linhas no máximo, idealmente poucas.
- **Faça uma coisa só.** Teste preciso: *uma função faz mais de uma coisa se você consegue extrair dela outra função cujo nome não seja apenas reformulação da implementação.* Se dá para dividir a função em **seções** (declarações, inicialização, seleção), ela faz mais de uma coisa.
- **Um nível de abstração por função.** Misturar conceitos essenciais com detalhes confunde: o leitor não distingue essência de detalhe. E, como janelas quebradas, uma vez misturado, mais detalhes se acumulam.
- **Regra descendente:** o programa lê-se como narrativa de cima para baixo, cada função seguida das do nível imediatamente abaixo.
- **Argumentos: quanto menos, melhor.** Zero é ideal, depois um, dois, três. O motivo não é estético: argumentos estão num nível de abstração diferente do nome da função, obrigando o leitor a processar detalhe irrelevante; e **cada argumento multiplica o espaço de casos de teste**.
  - Formas monádicas legítimas: perguntar algo sobre o argumento; transformar o argumento e retornar; ou tratar um evento (entrada sem saída, mudando estado do sistema — use com cautela, deixe óbvio que é evento).
  - **Argumentos booleanos declaram explicitamente que a função faz mais de uma coisa** — elimine-os.
  - **Argumentos de saída são anti-naturais**: espera-se entrada por argumento e saída por retorno. Se a função deve mudar estado de algo, que mude o do objeto em que é chamada.
- **Separe comando de consulta.** Ou faz algo, ou responde algo (§4.4).
- **Prefira exceções a códigos de erro** — códigos obrigam o chamador a tratar imediatamente e aninham condicionais. E **tratamento de erro é uma coisa só**: se uma função trata erro, ela deve *só* tratar erro.
- **Não se repita.**

### 6.3 Comentários

Posição de Martin: *"o uso adequado de comentários é compensar nosso fracasso em nos expressar no código... comentários são sempre fracassos"*. A razão não é estética: **comentários mentem**. Quanto mais antigo e distante do código, maior a chance de estar errado, porque não é realista que programadores os mantenham atualizados. Hunt chega ao mesmo por DRY: comentário duplica informação, e informação duplicada diverge.

Mas os mesmos autores catalogam **comentários que devem existir**:

| Comentário bom | Por quê |
|---|---|
| Legal/copyright | Obrigatório, não substituível por código |
| **Explicação de intenção / decisão** | O *porquê* não cabe no código |
| Esclarecimento de algo que você não pode alterar (API de terceiro) | Você não controla o código |
| Advertência de consequência | Impede otimização ingênua que quebraria o sistema |
| TODO | Marca dívida consciente — mas *nenhum TODO justifica deixar código ruim* |
| Amplificação de algo aparentemente irrelevante | Protege contra "limpeza" que quebra |
| Documentação de **API pública** | Consumidores externos não leem seu código |

Ruins, apagar sem cerimônia: murmúrio, redundante (`i++; // incrementa i`), enganoso, obrigatório por processo, diário/changelog, ruidoso, posicional/banner, atribuição e autoria (o controle de versão sabe), **código comentado** (*"uma abominação — apague; o controle de versão se lembra dele"*), informação não local, e Javadoc que só repete a assinatura.

**Critério unificado:** *escreva comentário quando ele carregar informação que o código não pode carregar — intenção, justificativa, contrato externo, advertência. Nunca escreva comentário que reafirme o que o código já diz. Antes de escrever qualquer comentário, tente extrair uma função com o nome do comentário* — heurística explícita de Fowler: *"sempre que sentimos necessidade de comentar algo, em vez disso escrevemos um método"*.

### 6.4 Formatação

Formatação é comunicação, não gosto.
- **Metáfora do jornal**: nome no topo diz do que se trata; detalhe aumenta conforme se desce.
- **Densidade vertical** (linhas relacionadas juntas) e **distância vertical** (variáveis perto do uso, funções chamadoras acima das chamadas).
- **Formatação de equipe vence formatação pessoal.** Um estilo por projeto, aplicado por ferramenta.
- **Estrutura acima de convenção** quando a estrutura já comunica; quando a convenção padrão existe e é conhecida, siga-a.

### 6.5 Objetos vs. estruturas de dados — a dicotomia

- **Objetos** escondem dados atrás de abstrações e expõem funções que operam sobre eles.
- **Estruturas de dados** expõem dados e não têm funções significativas.

Consequência: **código OO facilita adicionar novos tipos sem alterar funções existentes; código procedural facilita adicionar novas funções sem alterar estruturas existentes.** E o inverso também: OO dificulta adicionar funções; procedural dificulta adicionar tipos.

**Critério:** se o eixo de variação esperado é *tipos*, use polimorfismo; se é *operações*, use estruturas de dados e funções. Escolher errado gera o "objeto híbrido", meio dado meio comportamento, difícil de estender em qualquer direção.

**Lei de Deméter:** um método deve chamar apenas métodos do próprio objeto, de objetos que criou, de seus parâmetros e de seus campos — não de objetos retornados por esses. Cadeias `a.getB().getC().fazer()` acoplam o cliente à estrutura de navegação. **Ressalva:** a lei se aplica a *objetos*; sobre estruturas de dados puras a navegação encadeada é legítima, porque não há encapsulamento a violar.

### 6.6 Tratamento de erros

- **Use exceções, não códigos de retorno.**
- **Escreva primeiro o `try-catch-finally`** — isso define o escopo transacional antes de você começar.
- **Forneça contexto nas exceções**: mensagem que diga a operação e o motivo, suficiente para diagnosticar sem depurar.
- **Defina classes de exceção pelas necessidades do chamador**, não pela origem técnica; envolva APIs de terceiros para reduzir dependência.
- **Não retorne `null` nem passe `null`.** Retornar nulo empurra a verificação para todos os chamadores e cria erro de omissão. Prefira exceção ou um objeto que represente "vazio" com segurança (*Introduzir Objeto Nulo*, em Fowler).
- **Use exceções para problemas excepcionais** (Dica 34): se a condição é esperada no fluxo normal, não é exceção — é caso de negócio.

Camada de contrato (Hunt):
- **Projete com contratos** (Dica 31): pré-condições, pós-condições e invariantes explícitos, ainda que como asserções ou testes.
- **Encerre antecipadamente** (Dica 32, *crash early*): um programa morto causa muito menos dano do que um programa aleijado produzindo resultado errado.
- **Se não pode acontecer, use asserções para garantir que não aconteça** (Dica 33). Asserção documenta e verifica ao mesmo tempo.

### 6.7 Limites (código que não é seu)

- **Encapsule interfaces de terceiros.** Passar estruturas cruas de uma API alheia pelo sistema espalha conhecimento que você não controla; envolva-a numa classe que expõe só o que o seu sistema precisa.
- **Testes de aprendizagem**: escreva testes contra a biblioteca para aprendê-la e, principalmente, para **detectar quando a nova versão mudou o comportamento**.
- **Para código que ainda não existe**, defina a interface que *você* gostaria de ter e implemente um adaptador quando a peça real chegar. Isso mantém seu design dirigido pelas suas necessidades.

### 6.8 Metadados, configuração e geração

Hunt & Thomas (Dicas 29, 37 e 38):
- **Configure, não integre.** Escolhas que variam por cliente, ambiente ou política vão para metadados.
- **Coloque abstrações no código e detalhes em metadados.** O código expressa *como o sistema funciona*; os metadados, *como ele está funcionando agora*.
- **Escreva código que cria código** (Dica 29). Geradores ativos (rodam a cada build a partir de fonte única) são a resposta canônica à duplicação imposta.
- **Mantenha informações em texto simples** (Dica 20) — sobrevive a formatos proprietários, é diffável, versionável, legível por ferramentas que ainda não existem.
- **Automatize todo procedimento manual** (Dica 61). Martin converge: **construir e rodar todos os testes devem ser operações de um comando só**.

### 6.9 Higiene contínua

- **Não tolere janelas quebradas** (Dica 4). Um defeito ou trecho sujo deixado no lugar sinaliza que o padrão do projeto caiu, e a degradação acelera. Conserte, ou no mínimo isole e marque explicitamente.
- **Regra do escoteiro** (Martin): *deixe a área do acampamento mais limpa do que como você a encontrou*. A limpeza incremental é o que impede a entropia de vencer.
- **Corrija o problema, não o culpado** (Dica 24); **não entre em pânico** (Dica 25); **"select" não está com defeito** (Dica 26) — o bug quase sempre está no seu código, não na plataforma; **não suponha — teste** (Dica 27).
- **Encontre os erros apenas uma vez** (Dica 66): todo bug corrigido vira um teste automatizado que o impede de voltar. Martin diz o mesmo do lado positivo: **teste abundantemente perto de bugs**, porque bugs se agrupam.

---

## 7. Testes

### 7.1 Por que testar

Martin: *"os testes habilitam todas as '-idades', porque eles possibilitam as alterações."* Testes ruins comprometem sua capacidade de modificar o código; você perde a capacidade de melhorar a estrutura; o código degrada; no fim você perde os testes e o código apodrece. Fowler diz o mesmo pelo lado da refatoração: **sem testes, refatorar é apostar.** §7 e §8 não são dois assuntos, são um.

Hunt: **teste cedo, teste sempre, teste automaticamente** (Dica 62); *teste seu software ou seus usuários testarão* (Dica 49); e **projete para testar** (Dica 48) — testabilidade é decisão de projeto, não etapa posterior.

### 7.2 Testes limpos

*"O que torna um teste limpo? Três coisas: legibilidade, legibilidade e legibilidade."* — e isso é ainda **mais** importante em teste do que em produção, porque o teste é a documentação executável do comportamento.

- **Um conceito por teste**; e idealmente **uma asserção por teste**.
- **Padrão Construir-Operar-Verificar** explícito na forma do teste.
- **Crie uma linguagem de teste específica do domínio**: auxiliares que expressam a intenção, escondendo a mecânica. Testes duplicados e cheios de detalhe de infraestrutura são cheiro grave.
- **Código de teste tem o mesmo padrão de qualidade que produção** — mas não de eficiência: testes podem sacrificar performance por clareza.

**F.I.R.S.T.:**
- **Fast** — testes lentos deixam de ser rodados; você para de encontrar problemas cedo e não se sente livre para limpar o código.
- **Independent** — nenhum teste configura condições para o próximo; devem rodar em qualquer ordem. Dependência causa efeito dominó e oculta defeitos.
- **Repeatable** — rodam em qualquer ambiente, inclusive sem rede. Caso contrário, você sempre terá desculpa para as falhas.
- **Self-validating** — saída booleana. Nada de ler log ou comparar arquivos manualmente; do contrário a falha vira subjetiva.
- **Timely** — escritos imediatamente antes do código de produção. Depois disso, o código de produção já terá ficado difícil de testar.

### 7.3 Estratégia — cobertura de estados, não de linhas

Hunt faz a distinção decisiva: **teste a cobertura de estados, não a cobertura de código** (Dica 65). 100% de linhas executadas não diz nada sobre as combinações de estado que produzem falha. Martin converge: *"padrões de cobertura podem ser reveladores"* — cobertura é útil como **detector de omissão**, inútil como **meta**.

- **Use sabotadores para testar seus testes** (Dica 64): introduza deliberadamente um defeito e verifique se a suíte pega. Suíte que não falha quando o código quebra é decorativa.
- **Não pule testes triviais** — o retorno documental supera o custo. E **um teste ignorado é uma pergunta sobre uma ambiguidade**: mantenha-o desabilitado com explicação, em vez de apagá-lo.
- Níveis clássicos (Sommerville/Pressman): **unidade → integração → sistema/validação → aceitação**, com **revisões e inspeções** como verificação estática. A observação mais útil é econômica: **o custo de corrigir um defeito cresce por ordem de grandeza a cada estágio que ele atravessa** — erro de codificação é barato, erro de projeto é caro, **erro de requisito é o mais caro**, porque pode exigir reprojetar o sistema.
- Uso estratégico (Evans): testes de aceitação desenvolvidos em conjunto entre times cliente e fornecedor, rodando na integração contínua do fornecedor, são o que torna a relação CUSTOMER/SUPPLIER segura.

### 7.4 Duplos de teste

Fakes, stubs e mocks existem para tornar o teste **rápido, determinístico e independente** de recursos externos. Se você precisa de um duplo enorme e complicado, o teste está dizendo que **o acoplamento do código está errado** — o duplo difícil é sintoma, não problema de ferramenta. Taxonomia completa e custos em §7.9.

### 7.5 A pirâmide de testes — três níveis, três propósitos

| Nível | Escopo | Dependências | Custo/velocidade | Proporção sugerida |
|---|---|---|---|---|
| **Unidade** | uma classe / unidade pequena | substituídas por duplos (§7.9) | baratos, milissegundos | **~70%** |
| **Integração** (ou *de serviços*) | uma funcionalidade ou transação completa; várias classes, pacotes distintos | **reais** — banco, serviço remoto. Aqui **não faz sentido usar mock** | mais lentos, rodados com menos frequência | **~20%** |
| **Sistema** (ponta a ponta, ou *de interface*) | simula uma sessão de uso real | tudo real | caros, lentos e **frágeis** — pequena mudança na interface quebra o teste | **~10%** |

A proporção não é dogma, é economia: quanto mais alto na pirâmide, mais caro escrever, mais lento rodar e **mais difícil localizar a causa da falha**. No teste de sistema de um compilador você descobre que "o programa P executa errado" e ainda precisa achar qual unidade gerou código incorreto.

**O que mudou com o ágil** (e por que a prática antiga ainda aparece): antes, teste era **fase posterior**, feita por **equipe separada**, **manualmente**, e servia só para achar bug antes da produção. Hoje: testes **automatizados** (programas auto-testáveis), escritos **pelo próprio desenvolvedor da classe**, muitas vezes **antes** dela, e com três funções — achar bug, **impedir regressão** e **documentar o comportamento**. Michael Feathers leva isso ao limite: *código sem testes é código legado*.

**Vocabulário do framework** (xUnit/JUnit), útil porque os termos são usados trocados:

- **Teste** (*test method*): o método anotado que executa o teste.
- **Fixture**: o estado — dados e objetos — que o teste exercita. O nome vem da manufatura: o dispositivo que **fixa** a peça.
- **Caso de teste** (*test case*): a classe que agrupa métodos de teste.
- **Suíte de testes**: o conjunto de casos de teste executados pelo framework.
- **SUT** (*System Under Test*) ou **código de produção**: o que está sendo testado.

**Quando escrever teste de unidade** — quatro respostas, todas válidas:
1. Logo depois de implementar uma funcionalidade pequena (programa um pouco, testa um pouco).
2. **Antes** do código de produção (TDD, §3 e §7.10).
3. **Quando alguém reporta um bug**: comece escrevendo o teste que **reproduz** o bug e falha; corrija; o teste passa e a suíte ganha proteção permanente contra a regressão.
4. **Ao depurar**: em vez de espalhar `println` que depois será apagado, escreva um teste — o `println` some, o teste fica.

Como isso aparece em escala: no Google, todo código de produção deve ter testes de unidade e **a ferramenta de revisão destaca automaticamente código submetido sem testes**; no Facebook, o código novo precisa passar por testes de regressão executados automaticamente no commit e no push.

### 7.6 Test smells e a regra dos asserts

Complementando §7.2, três **test smells** — alertas para simplificar, não proibições absolutas:

- **Teste obscuro**: longo, complexo, difícil de entender. Idealmente cada teste exercita **um requisito**.
- **Teste com lógica condicional**: `if` ou laços dentro do teste. Teste de unidade deve ser **linear** — condicional prejudica o entendimento e cria caminhos não exercitados dentro do próprio teste.
- **Duplicação de código em testes**.

E a consequência que a maioria dos times esquece: **código de teste também se refatora**, com a mesma disciplina de §8 — para permanecer simples, linear e livre de duplicação.

**Um assert por teste?** A regra é boa por dois motivos concretos: legibilidade, e **quando falha você sabe imediatamente por quê** (um teste com dois asserts pode falhar por duas razões). Mas **não seja dogmático** — duas exceções legítimas:
- verificar **vários campos de um mesmo objeto** retornado (título, autor, ano, editora do mesmo livro);
- **um método simples** exercitado com várias entradas equivalentes (`repeat("20", 0..3)`).

Também é legítimo um teste **sem nenhum assert**: quando o que se verifica é o **lançamento de uma exceção**, o assert seria código morto — use o recurso do framework para declarar a exceção esperada.

**Testes flaky (erráticos)** merecem seção própria dentro do princípio *determinístico*: são testes cujo resultado varia entre execuções. A causa dominante é **concorrência** — o caso clássico é o teste que chama uma função assíncrona e usa `sleep(1000)` esperando o resultado: passa se a thread terminar antes, falha se demorar. Dado que calibra a expectativa: um estudo do próprio **Google encontrou ~16% dos seus testes sujeitos a resultado não determinístico**. O dano não é só o falso alarme — é o tempo gasto investigando uma falha que não existe, e a erosão da confiança na suíte. **Solução correta não é aumentar o sleep: é refatorar para extrair a versão síncrona e testá-la** (§7.8).

### 7.7 Cobertura — o que medir, e qual meta não perseguir

**Cobertura de comandos** = comandos executados pelos testes ÷ total de comandos. É a definição mais comum, e existem outras:

| Definição | O que mede |
|---|---|
| **Cobertura de comandos (C0)** | % de comandos executados |
| **Cobertura de branches (C1)** | % de ramos executados — um `if` gera **dois** ramos. **Mais rigorosa que C0** |
| **Cobertura de funções** | % de funções executadas |
| **Cobertura de chamadas de funções** | % das linhas que chamam funções e são exercitadas |

O exemplo que resolve a confusão: `abs(x) { if (x<0) x = -x; return x; }` testado só com `abs(-1)` tem **100% de cobertura de comandos e 50% de branches**. Por isso, quando alguém cita "cobertura" sem qualificar, **pergunte qual**.

**Qual a cobertura ideal? Não existe número mágico.** Depende da complexidade dos requisitos e da criticidade do sistema (§1.2). **Não precisa ser 100%**: sempre há métodos triviais (getters/setters) e métodos de teste difícil (interface gráfica, assíncronos).

Faixas de referência: times que valorizam testes **chegam facilmente a ~70%**; **abaixo de 50% é preocupante**; com **TDD costuma ficar acima de 90%** (raramente 100%). No Google (dados de 2014), a **mediana era 78%**, com recomendação interna de 85% — explicitamente **"não escrita em pedra"**; variava por linguagem (C++ perto de 60%, Python acima de 80%).

**A regra de uso, que vale mais que qualquer número:** *não fixe um valor de cobertura a ser sempre atingido*. Em vez disso:
1. **Monitore a evolução** ao longo do tempo — a queda indica que o time está relaxando, e é isso que interessa saber.
2. **Avalie os trechos não cobertos** um a um, para confirmar que são irrelevantes ou realmente difíceis de testar.

Isso reconcilia com §7.3: cobertura é **detector de omissão**, e cobertura de **estados** (Hunt) é o que importa — 100% de linhas não diz nada sobre as combinações de estado que produzem falha.

### 7.8 Testabilidade — projetar para poder testar

**Testabilidade** = quão fácil é escrever testes para um sistema. A consequência prática é contraintuitiva e vale como regra: **parte relevante do esforço para escrever bons testes deve ser gasta no projeto do código de produção, não no projeto dos testes** (*design for testability*).

A boa notícia é que **não há princípio novo a aprender**: código com alta coesão, baixo acoplamento, responsabilidade única, separação apresentação/modelo, inversão de dependências e Demeter (§5) **já é testável**. Baixa testabilidade é sintoma de violação desses princípios — e é um dos melhores detectores que existem, porque aparece **antes** de o problema custar caro.

**Padrão de correção mais comum — extrair o domínio da borda.** Uma classe que estende a infraestrutura (um servlet, um controlador de framework, um *handler*) é difícil de instanciar e de testar, porque arrasta uma cadeia de tipos externos. A solução é extrair a lógica de domínio para uma classe própria, sem dependência da infraestrutura, e testá-la. Objeção previsível: *"assim não testo o código completo"* — e a resposta é a que vale para qualquer caso: **é melhor testar a parte de domínio do que deixar tudo descoberto**.

Mesmo padrão para **código assíncrono**: extraia a versão **síncrona** da computação e teste-a; deixe a casca assíncrona sem teste de unidade em vez de escrever um teste flaky com `sleep` (§7.6).

### 7.9 Duplos de teste — mocks, stubs e o custo que eles cobram

**Problema que os duplos resolvem:** testar uma classe que depende de um serviço externo (API REST, banco) violaria duas coisas ao mesmo tempo — o **escopo** (deixaria de ser teste de unidade) e a **velocidade** (FIRST, §7.2).

**Taxonomia dos objetos dublê (*test doubles*, Meszaros):**

| Tipo | O que é |
|---|---|
| **Dummy** | passado como argumento mas **nunca usado** — existe só para satisfazer o sistema de tipos |
| **Fake** | implementação **real porém simplificada** (ex.: banco de dados simulado em memória com tabelas hash) |
| **Stub** | responde chamadas com respostas programadas; o teste verifica o **estado** do SUT |
| **Mock** | além do estado, verifica o **comportamento**: se determinado método foi chamado, com que argumentos, quantas vezes (`verify(m).send(...)`) — o chamado **teste comportamental** ou **de interação** |

Na prática cotidiana, *mock* e *stub* são usados como sinônimos; a distinção só importa quando você precisa dizer **o que está sendo verificado** — estado ou interação.

**Frameworks** (Mockito e equivalentes) eliminam a escrita manual de classes-dublê: criam o duplo por reflexão e o "programam" com uma pequena linguagem de domínio (`when(...).thenReturn(...)`), inclusive com regra geral + exceções específicas por argumento.

**Os três custos — declare-os antes de encher o teste de mocks:**
1. **Acoplamento.** O teste normal acopla-se apenas à *assinatura* do método testado; com mocks ele passa a depender de **estruturas internas** do que é testado — muda o formato de uma string de saída e o teste quebra sem que nada tenha regredido. Testes viram frágeis.
2. **Nem tudo é mockável**: classes e métodos *final*, métodos estáticos e construtores, em geral, não são.
3. **Duplo grande e complicado é sintoma de acoplamento errado** no código de produção (§7.4) — a resposta certa costuma ser refatorar, não sofisticar o mock.

E a fronteira que decide o uso: **em testes de integração não se usa duplo** — o objetivo ali é justamente exercitar a dependência real (§7.5).

### 7.10 TDD, e os testes que não são de unidade

**TDD** (§3 traz o laço e as três leis de Martin). Os **três objetivos declarados**, na leitura de Valente, explicam por que ele funciona:
1. **Impedir que o teste fique para depois** — sendo a primeira atividade, não há "amanhã eu escrevo".
2. **Produzir código com alta testabilidade** — sabendo que o teste vem primeiro, você projeta a classe para ser testável (daí a cobertura acima de 90%).
3. **Melhorar o design** — ao escrever o teste, você é o **primeiro cliente** da sua classe: interface mais simples, nomes legíveis, menos parâmetros.

O **estado vermelho já é vitória**: um teste que falha é uma **especificação** do que precisa ser implementado. Entregue o vermelho **compilando** (esqueleto da classe e assinaturas). Depois verde — que pode ser alcançado por passos pequenos, inclusive retornando constantes no início. Depois refatorar **o código e o teste**. Nota de Kent Beck que desfaz uma falsa dicotomia: TDD **não é** puramente caixa-preta — a inspiração para o próximo teste costuma vir de olhar o código que o teste anterior fez existir.

**Caixa-preta × caixa-branca:**
- **Caixa-preta** (*testes funcionais*): escritos só a partir da interface — nome, parâmetros, tipos, exceções.
- **Caixa-branca** (*testes estruturais*): escritos usando a estrutura interna, inclusive dados de cobertura (quais ramos faltam).
- Teste de unidade **não é intrinsecamente** nem um nem outro: depende de como foi escrito.

**Seleção de dados de teste** (para caixa-preta):
- **Classes de equivalência**: particione as entradas em conjuntos com a mesma chance de revelar bug e teste **um valor por classe** (uma faixa de alíquota de imposto = uma classe).
- **Análise de valor limite**: teste os **limites de cada classe e seus vizinhos imediatos** — para a faixa `1.903,99 … 2.826,65`, teste 1.903,98 / 1.903,99 / 2.826,65 / 2.826,66. É onde os bugs se concentram.
- **Teste exaustivo é impossível** — mesmo uma função de dois inteiros levaria séculos. **Teste randômico não é recomendado** na maioria dos casos: sorteia vários valores da mesma classe de equivalência e deixa outras classes descobertas.

**Testes de aceitação**: feitos **pelo cliente, com dados do cliente**, e são **manuais**. São os únicos que constituem **validação** e não apenas verificação (§1.1). Em método ágil, é o que fecha uma história no fim do sprint (§2.4). Dividem-se em **alfa** (poucos usuários, ambiente controlado) e **beta** (grupo maior, ambiente real).

**Testes de requisitos não funcionais** — os demais tipos só verificam requisitos funcionais:
- **Desempenho / carga**: simular o pico (a Black Friday) antes que ele aconteça.
- **Usabilidade**: observação de usuários reais usando o sistema.
- **Falhas**: simular eventos anormais — queda de serviços, queda de um data center inteiro.

---

## 8. Refatoração e evolução

### 8.1 Definição e disciplina

- **Refatoração (substantivo):** alteração na estrutura interna para tornar o software mais fácil de entender e menos custoso de modificar, **sem alterar seu comportamento observável**.
- **Refatorar (verbo):** reestruturar aplicando uma série de refatorações, sem alterar o comportamento observável.

Contraste esclarecedor de Fowler: otimização de desempenho **também** preserva comportamento e **também** altera estrutura interna — a diferença é o **propósito**. Otimização frequentemente torna o código mais difícil de entender; refatoração, por definição, mais fácil. Se não facilitou o entendimento, não foi refatoração.

Disciplina: passos pequenos, testes a cada passo, e **os dois chapéus** (§3). *"Quando você refatora, faz questão de não acrescentar funcionalidade; apenas reestrutura. Você não acrescenta novos testes — a não ser que encontre um caso que não havia percebido antes."*

### 8.2 Quando refatorar

Fowler é explícito contra "sprint de refatoração": *"sou contra separar tempo para refatorar. Refatoração é algo que você faz o tempo todo em pequenas rajadas. Você não decide refatorar; você refatora porque quer fazer alguma outra coisa e refatorar ajuda a fazê-la."*

1. **Regra de Três** (Don Roberts): na primeira vez você faz; na segunda você estremece com a duplicação mas faz; **na terceira, você refatora.**
2. **Ao acrescentar funcionalidade.** Para entender o código que precisa mudar, e porque *"se eu tivesse projetado assim, acrescentar esta funcionalidade seria fácil"* — então torne-o assim primeiro. Fowler insiste que faz isso **principalmente por ser mais rápido**, não por virtude.
3. **Ao corrigir um defeito.** *"Se você recebe uma notificação de falha, é sinal de que precisa refatorar, porque o código não estava claro o suficiente para que você percebesse que havia uma falha."*
4. **Ao revisar código.** Refatorar durante a revisão transforma sugestões abstratas em resultado visível e gera um segundo nível de ideias que não apareceria de outra forma. Formato: **revisor + autor juntos** no código; grupos maiores servem melhor para revisão de *projeto* (diagramas, cenários), não de código.

Hunt (Dica 47): **refatore cedo, refatore sempre.** Sintomas-gatilho: duplicação, projeto não ortogonal, conhecimento desatualizado, desempenho.

### 8.3 Quando NÃO refatorar

- **Quando o código simplesmente não funciona.** Se ao tentar testá-lo você vê que está cheio de falhas e não estabiliza, **reescreva**. *"O código tem que funcionar corretamente na maior parte do tempo antes de você refatorá-lo."* Fowler admite não ter boas regras aqui — a alternativa promissora é **refatorar o sistema em componentes fortemente encapsulados e então decidir refatorar-ou-reconstruir componente a componente**.
- **Quando o prazo está muito próximo.** O ganho apareceria depois do prazo. **Esta é a única razão legítima para adiar.**

Metáfora de Ward Cunningham que os autores adotam: **refatoração não terminada é dívida.** A maioria das empresas precisa de algum endividamento para funcionar; mas com dívida vêm juros — o custo extra de manutenção e extensão causado por código complexo demais. Você suporta alguns juros; se crescerem demais, é esmagado. *"É importante gerenciar suas dívidas, pagando partes delas por meio da refatoração."*

Conclusão de Fowler: **fora da véspera de um prazo, "não tenho tempo para refatorar" é diagnóstico invertido — não ter tempo suficiente geralmente é sinal de que você precisa refatorar.**

### 8.4 Catálogo de cheiros

Beck e Fowler são explícitos sobre a natureza do instrumento: *"não tentaremos lhe dar critérios precisos... nenhum conjunto de métricas se compara à intuição humana."* Cheiros são **indicações**; você desenvolverá sua própria percepção.

| Cheiro | Diagnóstico | Movimento típico |
|---|---|---|
| **Código Duplicado** | O cheiro nº 1 | Extrair Método; subir na hierarquia; Extrair Classe; Substituir o Algoritmo |
| **Método Longo** | Distância semântica entre o que faz e como faz | Extrair Método; Substituir Temporária por Consulta; Introduzir Objeto Parâmetro; Substituir Método por Objeto Método |
| **Classe Grande** | Variáveis de instância demais → duplicação por perto | Extrair Classe / Subclasse / Interface |
| **Lista de Parâmetros Longa** | Cliente sabe demais | Substituir Parâmetro por Método; Preservar o Objeto Inteiro; Introduzir Objeto Parâmetro |
| **Alteração Divergente** | *Uma* classe muda por *vários* motivos | Extrair Classe por eixo de mudança |
| **Cirurgia com Rifle** | *Uma* mudança toca *várias* classes | Mover Método/Campo para concentrar; Internalizar Classe |
| **Inveja dos Dados** | Método mais interessado em outra classe | Mover Método (heurística: vá para onde estão **mais** dados) |
| **Grupos de Dados** | Os mesmos 3–4 dados juntos em toda parte | Extrair Classe; teste: apagando um valor, os outros ainda fazem sentido? |
| **Obsessão Primitiva** | Primitivos onde deveria haver conceito | Substituir Atributo por Objeto; Substituir Enumeração por Classe/Subclasses/State |
| **Comandos Switch** | O mesmo switch espalhado | Mover para a classe certa e Substituir Condicional por Polimorfismo — **mas** se são poucos casos, num único método, sem expectativa de crescimento, polimorfismo é exagero |
| **Hierarquias Paralelas** | Toda subclasse aqui exige subclasse ali | Fazer uma hierarquia referenciar a outra |
| **Classe Ociosa** | Não se paga | Condensar Hierarquia; Internalizar Classe |
| **Generalidade Especulativa** | "Vamos precisar disso um dia" | Condensar Hierarquia; Remover Parâmetro; Renomear. **Sinal preciso: os únicos usuários são os testes** |
| **Campo Temporário** | Variável válida só às vezes | Extrair Classe; Introduzir Objeto Nulo |
| **Cadeias de Mensagens** | Cliente acoplado à estrutura de navegação | Ocultar Delegação; ou mover o uso para dentro da cadeia |
| **Intermediário** | Delegação demais, classe sem conteúdo | Remover Intermediário |
| **Intimidade Inadequada** | Classes fuçando os privados uma da outra | Mover Método/Campo; Substituir Herança por Delegação |
| **Classes Alternativas com Interfaces Diferentes** | Mesma coisa, assinaturas diferentes | Renomear Método; Mover Método; Extrair Superclasse |
| **Biblioteca de Classes Incompleta** | Falta função na biblioteca alheia | Introduzir Método Externo / Extensão Local |
| **Classe de Dados** | Só getters e setters | Encapsular Campo/Coleção; mover comportamento para dentro |
| **Herança Recusada** | Subclasse não quer o que herdou | Descer Método/Campo; Substituir Herança por Delegação |
| **Comentários** | Frequentemente desodorante de código ruim | Extrair Método com o nome do comentário; Introduzir Asserção |
| **Variáveis Globais** | Impedem entender um módulo isoladamente: `return x + g` não pode ser compreendido só lendo a função, porque `g` muda em qualquer lugar do programa | Passar como parâmetro; encapsular em objeto com dono claro; injetar dependência |
| **Objetos Mutáveis** | Estado alterável espalha efeito à distância e destrói o raciocínio local (Fowler acrescenta este cheiro na 2ª edição) | Tornar imutável (como `String`); Substituir Atributo por Objeto de valor; Remover Setter |

### 8.5 Catálogo de movimentos

- *Compondo métodos:* Extrair Método · Internalizar Método · Internalizar Variável Temporária · Substituir Variável Temporária por Consulta · Introduzir Variável Explicativa · Dividir Variável Temporária · Remover Atribuições a Parâmetros · Substituir Método por Objeto Método · Substituir o Algoritmo
- *Movendo recursos:* Mover Método · Mover Campo · Extrair Classe · Internalizar Classe · Ocultar Delegação · Remover Intermediário · Introduzir Método Externo · Introduzir Extensão Local
- *Organizando dados:* Auto-Encapsular Campo · Substituir Atributo por Objeto · Valor↔Referência · Substituir Vetor por Objeto · Duplicar Dados Observados · Associação Uni↔Bidirecional · Substituir Números Mágicos por Constantes Simbólicas · Encapsular Campo · Encapsular Coleção · Substituir Registro por Classe de Dados · Substituir Enumeração por Classe / Subclasses / State-Strategy · Substituir Subclasse por Campos
- *Simplificando condicionais:* Decompor Condicional · Consolidar Expressão Condicional · Consolidar Fragmentos Duplicados · Remover Flag de Controle · Substituir Condição Aninhada por Cláusulas Guarda · Substituir Condicional por Polimorfismo · Introduzir Objeto Nulo · Introduzir Asserção
- *Simplificando chamadas:* Renomear Método · Acrescentar/Remover Parâmetro · **Separar a Pesquisa do Modificador** · Parametrizar Método · Substituir Parâmetro por Métodos Explícitos · Preservar o Objeto Inteiro · Substituir Parâmetro por Método · Introduzir Objeto Parâmetro · Remover Método de Gravação · Ocultar Método · Substituir Construtor por Método Fábrica · Encapsular Downcast · Substituir Código de Erro por Exceção · Substituir Exceção por Teste
- *Generalização:* Subir/Descer Campo, Método, Corpo do Construtor · Extrair Subclasse / Superclasse / Interface · Condensar Hierarquia · Criar Método Padrão · **Substituir Herança por Delegação** e **Substituir Delegação por Herança**
- *Grandes refatorações:* Desembaraçar Herança · Converter Projeto Procedural em Objetos · **Separar o Domínio da Apresentação** · Extrair Hierarquia

### 8.6 Refatoração e projeto — a mudança de ênfase

Antes da refatoração como disciplina, todo requisito puxava a pergunta "como isto pode mudar?", e a resposta era **construir flexibilidade antecipada**. Mas *"flexibilidade tem seu preço: soluções flexíveis são mais complexas"*, e a frustração é que **a maior parte dessa flexibilidade nunca é usada** — alguma é necessária, mas é impossível prever qual. Para ganhar a flexibilidade certa, você é forçado a embutir muito mais do que precisa.

Com refatoração, a pergunta muda de *"quão flexível preciso ser?"* para: **"quão difícil será refatorar uma solução simples em uma flexível?"**. Se a resposta for "muito fácil" — e, na maioria das vezes, é — **implemente a solução simples**.

Fowler desarma o extremo oposto: *"embora executar apenas refatoração funcione, não é a maneira mais eficiente de trabalhar. Mesmo os praticantes de XP realizam algum projeto primeiro."* O projeto inicial não desaparece; deixa de buscar *a* solução e passa a buscar **uma solução razoável**.

Evans dá a versão de domínio (**REFACTORING TOWARD DEEPER INSIGHT**): modelos valiosos não emergem de imediato; exigem mergulhar, implementar um design baseado num modelo provavelmente ingênuo, e transformá-lo repetidamente. De tempos em tempos, esse descascar de cebola leva a um **breakthrough** — ruptura para um modelo muito mais profundo, com cascata de mudanças de design. Gatilhos: times de exploração, arte prévia (modelos publicados do domínio), e **crise como oportunidade**.

### 8.7 Evolução, manutenção e legado

**Leis de Lehman:**
1. Um programa deve mudar continuamente para continuar sendo útil.
2. À medida que muda, **sua estrutura se degrada** — a menos que se invista em contê-la.
3. A taxa de mudança ao longo da vida é aproximadamente constante e **independente dos recursos disponíveis**.
4. A mudança incremental por lançamento é aproximadamente constante.
5. Novas funcionalidades precisam ser acrescentadas para manter a satisfação do usuário.

**Taxonomia de manutenção — a de Valente, mais operacional que a clássica:**

| Tipo | O que é |
|---|---|
| **Corretiva** | corrigir bugs **reportados** por usuários ou outros desenvolvedores |
| **Preventiva** | corrigir bugs **latentes**, que ainda não causaram falha (o caso canônico é o esforço do Bug do Milênio: converter datas DD-MM-AA para DD-MM-AAAA **antes** da virada) |
| **Adaptativa** | adaptar a mudanças no ambiente: tecnologia (migrar Python 2.7 → 3.0), legislação, integração, ou customização para um novo cliente |
| **Refactoring** | melhorar código/projeto **sem alterar comportamento** (§8.1) |
| **Evolutiva** | acrescentar funcionalidade ou aperfeiçoar as existentes — é o que faz sistemas durarem décadas |

Equivalência com a classificação de **Lientz & Swanson (1978)**, que ainda aparece em texto acadêmico: corretiva = corretiva; **perfectiva** ≈ evolutiva; **adaptativa** ali cobre só mudança de ambiente (não inclui customização para cliente novo); **preventiva** ali significa aumentar manutenibilidade — o que hoje chamamos de refactoring.

**Sistema legado** é o sistema antigo baseado em linguagem, SO ou banco tecnologicamente ultrapassados — manutenção mais cara e mais arriscada. A ressalva importa: **legado não significa irrelevante** — com frequência são exatamente esses sistemas que executam as operações críticas do cliente (sistemas bancários escritos em COBOL nos anos 70–80, hoje com interface web e mobile integrada aos módulos originais).

**Três tipos de manutenção** (Sommerville), com custo crescente de correção: **reparo de defeito** (erro de código é barato; de projeto é caro; **de requisito é o mais caro**, pode exigir reprojeto), **adaptação ao ambiente**, **acréscimo de funcionalidade** (usualmente a maior em escala).

**A economia, e por que é ignorada:** quase sempre compensa investir em projeto e implementação para reduzir o custo de mudanças futuras — acrescentar funcionalidade após a entrega é caro porque exige aprender o sistema e analisar impacto. Sommerville aponta os dois motivos reais da relutância: (a) empresas planejam investimento em ciclos curtos e gestores são incentivados a reduzir custo de curto prazo, enquanto o ganho é de longo prazo e não mensurável no mesmo período; (b) coletar os dados que provariam o benefício é caro, então quase ninguém coleta.

**Contenção da degradação:** reengenharia, transformações de arquitetura e **refatoração** — Sommerville nomeia refatoração como o instrumento. Prevenção: especificação precisa, desenvolvimento com testes a priori, projeto orientado a objetos, gerenciamento de configuração.

**Reescrever do zero:** Brooks — o primeiro sistema construído é quase sempre pouco utilizável, e o descarte-e-reprojeto **vai acontecer**; entregar o primeiro sistema aos usuários ganha tempo ao custo de agonia do usuário e má reputação difícil de superar. Fowler — reescreva quando o código **não funciona** e não estabiliza. Critério combinado em §11.2.

---

## 9. Desempenho e algoritmos

### 9.1 Ordem de grandeza é design; constante é otimização

**O tempo de execução não se mede em segundos, mede-se pelo crescimento** — Big O, o número de operações no pior caso. Classes comuns, melhor→pior: O(log n) → O(n) → O(n log n) → O(n²) → O(n!).

- **Pesquisa binária** O(log n) — exige lista ordenada; dramaticamente melhor que pesquisa simples O(n), e a vantagem *aumenta* com o tamanho.
- **Array vs. lista encadeada**: array dá leitura aleatória O(1) e inserção/remoção no meio O(n); lista encadeada dá inserção/remoção O(1) e leitura O(n). **Escolha pelo padrão de acesso dominante, não por hábito.**
- **Tabela hash**: busca, inserção e remoção em tempo constante no caso médio; O(n) no pior. Usos canônicos: modelar relações, filtrar duplicatas, cache/memoização. Cuidados: boa distribuição da função hash e **fator de carga** — acima de ~0,7, redimensione.
- **Ordenação**: quicksort O(n log n) em média, O(n²) no pior; merge sort O(n log n) sempre. **Quicksort costuma ser mais rápido na prática apesar do pior caso, porque a constante é menor** — exemplo canônico de que a constante importa **quando as ordens são iguais** e é irrelevante quando são diferentes.
- **Grafos**: busca em largura responde "existe caminho de A para B?" e dá o **caminho mínimo em número de arestas**; Dijkstra dá o caminho de **menor peso** e **não funciona com arestas negativas**.
- **Guloso**: otimiza localmente esperando ótimo global; simples e rápido; nem sempre ótimo — mas bom **algoritmo de aproximação**.
- **Programação dinâmica**: quando o problema é otimizar algo sujeito a um limite e pode ser dividido em subproblemas **discretos**. Toda solução envolve uma tabela; cada célula é um subproblema.
- **NP-completo**: sem solução rápida conhecida. Ao reconhecer um (caixeiro-viajante, cobertura de conjuntos, cliques, "todas as combinações"), **pare de procurar solução exata e vá para aproximação**.

Hunt: **estime a ordem dos seus algoritmos** (Dica 45) — antes de escrever, saiba se está criando O(n²) sobre um conjunto que vai crescer — e **teste suas estimativas** (Dica 46), porque a análise assintótica ignora constantes e efeitos de memória que podem dominar em tamanhos reais.

### 9.2 Otimização: as três abordagens

1. **Orçamento de tempo** — cada componente recebe orçamento de tempo e memória. Necessário em **tempo real crítico**, onde dado atrasado é dado errado. Exagero para o resto.
2. **Atenção constante** — todos otimizando o tempo todo. *"É comum e intuitivamente atrativa, mas não funciona muito bem."* As melhorias se espalham, cada uma feita com visão estreita do comportamento global, tornam o código mais difícil de trabalhar e desaceleram o desenvolvimento — **e normalmente o software nem fica mais rápido**.
3. **Fatorar bem e otimizar depois, medindo** — a recomendada. Fundamento estatístico: **a maioria dos programas gasta a maior parte do tempo numa pequena fração do código**; otimizar tudo uniformemente desperdiça ~90% do esforço.

Procedimento: rode sob **profiler**; identifique os pontos quentes reais; otimize **só** neles; e, como na refatoração, **em passos pequenos — compile, teste e meça a cada passo, desfazendo o que não melhorou**.

*"O segredo do software rápido, em todos os contextos exceto tempo real, é escrever software ajustável primeiro e então ajustá-lo para uma velocidade suficiente."* Benefício composto: código bem fatorado (a) libera tempo para ajustar, porque funcionalidades saem mais rápido, e (b) torna o ajuste localizado e barato.

O caso relatado por Garzaniti é instrutivo em dois aspectos: o gargalo real (criação repetida de strings enormes) **não era o que a equipe supunha**, e o sistema bem fatorado permitiu paralelizar em três dias um programa não projetado para threads.

**Reconciliação com Bhargava (§11.6):** escolher estrutura de dados e algoritmo **não é otimização prematura** — é design. A regra de Fowler proíbe otimizar constantes antes de medir; não autoriza escolher O(n²) por preguiça.

### 9.3 Escala e distribuição

**Escalabilidade** (atender mais carga) e **elasticidade** (absorver picos súbitos) são características distintas e frequentemente conflitantes com consistência e simplicidade. Antes de distribuir, releia as falácias (§5.6); depois de distribuir, saiba que você trocou complexidade de *código* por complexidade de *operação* — e que essa troca é irreversível na prática.

---

## 10. Processo, estimativa, equipe e risco

### 10.1 Anatomia genérica do processo

Pressman reduz qualquer processo a **cinco atividades metodológicas**: comunicação → planejamento → modelagem → construção → entrega, aplicadas **iterativamente**, cada iteração produzindo incremento utilizável. Sobre elas correm **atividades de apoio**: acompanhamento e controle, gestão de riscos, garantia de qualidade, **revisões técnicas**, medição, gerenciamento de configuração, gestão de reúso e produção de artefatos.

**O processo deve ser adaptado** ao problema, ao projeto, ao time e à cultura. Eixos legítimos de adaptação: fluxo de atividades e interdependências; grau de definição de tarefas; artefatos exigidos; como se aplicam qualidade e controle; grau de rigor; envolvimento do cliente; autonomia do time.

**Os sete princípios de Hooker** (via Pressman), filtro para qualquer decisão de prática:
1. **A razão de existir** — o sistema existe para agregar valor ao usuário; antes de qualquer requisito, funcionalidade ou plataforma, pergunte "isso agrega valor real?". Se não, não faça. Todos os outros se apoiam neste.
2. **KISS** — o mais simples possível, mas não simplista. Simplificar exige reflexão e várias iterações; "simples" não é "gambiarra".
3. **Mantenha a visão** — sem integridade conceitual, o projeto vira colcha de retalhos. Ter alguém responsável por manter a visão e reforçar a adequação é o que assegura o êxito.
4. **O que um produz, outros consomem.**
5. **Esteja aberto para o futuro** — resolva o problema geral, não apenas o específico. *(Colide com "Generalidade Especulativa"; ver §11.4.)*
6. **Planeje visando reúso** — mas o retorno não é automático.
7. **Pense!** — pensar com clareza antes de agir quase sempre produz melhor resultado; e um efeito colateral de pensar é **aprender a reconhecer quando você não sabe algo**.

### 10.2 Integridade conceitual e estrutura da equipe

Brooks: *"a integridade conceitual é a consideração mais importante no projeto do sistema. É melhor ter um sistema omitindo certas funcionalidades e melhorias anômalas, mas refletir um conjunto único de ideias de projeto, do que ter um que contenha muitas ideias boas, mas independentes e descoordenadas."*

O teste de qualidade que ele propõe é uma **razão**: **função ÷ complexidade conceitual**. Nem função sozinha nem simplicidade sozinha definem bom design. Um sistema com muitas funções e conceitos incoerentes falha; um sistema simples que exige combinações inesperadas para expressar o que se quer também falha — **simplicidade não basta, é preciso ser direto**.

Consequência organizacional: **integridade conceitual exige que o design proceda de uma mente, ou de um número muito pequeno de mentes concordantes** — o que colide com a pressão de cronograma, que exige muitas mãos. As duas técnicas de Brooks: **(a) separar cuidadosamente arquitetura de implementação**, e **(b)** estruturar o time de implementação (o "time cirúrgico") para que poucos decidam e muitos apoiem.

O mecanismo de coerência que funciona na prática: o mesmo grupo — arquitetos, usuários e implementadores — reunindo-se regularmente; propostas **escritas e formais**, porque a formalidade concentra a atenção e força a decisão; e **atribuição clara de poder de decisão** ao arquiteto-chefe.

**Lei de Brooks:** *acrescentar mão de obra a um projeto de software atrasado torna-o mais tardio.* O mecanismo importa mais que o slogan: homens e meses só são intercambiáveis quando a tarefa pode ser dividida **sem comunicação**. Com restrições sequenciais, mais esforço não tem efeito ("a geração de uma criança leva nove meses, não importa quantas mulheres sejam designadas"). Com particionamento **e** comunicação, o esforço de comunicação soma-se ao trabalho e cresce quadraticamente. Somam-se treinamento e reparticionamento.

Quando o cronograma escorrega: reestimar o cronograma **inteiro** (não só o marco perdido), **cortar escopo**, ou aceitar o atraso — nunca adicionar pessoas ao caminho crítico. *"Mais projetos de software deram errado por falta de tempo do que por todas as outras causas combinadas."*

**Efeito do segundo sistema:** o segundo sistema que um arquiteto projeta é o mais perigoso — é onde ele acumula todas as ideias que a disciplina o obrigou a deixar de fora do primeiro. Autodisciplina explícita é a única defesa.

Richards & Ford, versão contemporânea: **atenção aos sinais de que o time está grande demais**; equipes eficazes precisam de nível de controle calibrado (nem arquiteto de torre de marfim, nem ausência); **checklists** são o instrumento leve que funciona onde documentação pesada não funciona.

### 10.3 Estimativa

**Procedimento (Hunt):**
1. **Entenda o que está sendo pedido** — inclusive o escopo, geralmente implícito. Frequentemente o escopo escolhido faz parte da resposta ("supondo que não haja acidentes, chego em 20 minutos").
2. **Construa um modelo do sistema** — efeito colateral valioso: modelar revela padrões e processos não aparentes, e às vezes leva a reformular o pedido ("você pediu X; parece que Y, uma variante, roda na metade do tempo perdendo só um recurso").
3. **Decomponha o modelo em componentes** e descubra as regras de interação.
4. **Dê valor a cada parâmetro** — concentre precisão nos de maior impacto. **Parâmetros aditivos importam menos que multiplicativos/divisores.**
5. **Calcule as respostas** e **fundamente-as nos parâmetros críticos**. Se um resultado parecer estranho, **não o descarte** — provavelmente você não entendeu o problema ou o modelo está errado, e essa informação é valiosa.
6. **Registre suas estimativas e compare com o realizado.** Quando errar, descubra por quê.

**Escala de unidades como comunicação de precisão:**

| Duração estimada | Comunique em |
|---|---|
| 1–15 dias | dias |
| 3–8 semanas | semanas |
| 8–30 semanas | meses |
| > 30 semanas | pense muito antes de dar qualquer número |

"130 dias úteis" comunica precisão que você não tem; "cerca de seis meses" comunica a incerteza real. **Escolha a unidade que reflete a precisão que você pretende transmitir.**

Atalho antes de qualquer modelagem: **pergunte a alguém que já passou pelo problema.**

**Advertência de Brooks:** o homem-mês é *"um mito perigoso e enganoso"* porque implica que homens e meses são intercambiáveis. O otimismo sistemático dos programadores tem causa identificável: o meio é extremamente maleável (constrói-se com puro pensamento), então esperamos poucas dificuldades — mas as dificuldades vêm das **ideias falhas**, não do meio. E num esforço grande, com muitas tarefas encadeadas, a probabilidade de que **todas** deem certo torna-se ínfima.

Resposta correta quando pressionado por uma estimativa que você não pode dar: **"eu volto a você com isso."**

### 10.4 Riscos

**Matriz de risco:** **impacto** × **probabilidade** → baixo (1–2) / médio (3–4) / alto (6–9).

**Risk storming**, e o motivo de cada etapa:
1. **Identificação — individual e antecipada.** Deliberadamente **não colaborativa**, para evitar ancoragem: cada participante classifica sozinho antes de ouvir os outros.
2. **Consenso — colaborativo.** As divergências são o produto valioso. Quando um participante vê risco alto e ninguém mais vê, a conversa revela experiência que ninguém tinha — *"sem o envolvimento desse participante, ninguém teria visto o alto risco (até estar em produção, claro)"*.
3. **Mitigação.**

Regras: **restrinja cada sessão a uma dimensão** (performance, disponibilidade, perda de dados) para evitar confusão; e **atribua sempre risco máximo (9) a tecnologias não comprovadas ou desconhecidas** — a matriz não se aplica ao que você não conhece. Detalhe revelador: quando um participante marcou risco alto porque **não sabia o que era a tecnologia**, isso *é* o risco. Desconhecimento da equipe é risco arquitetural real, não falha pessoal.

Pressman e Sommerville complementam a mecânica: identificar → projetar consequências → avaliar impacto/probabilidade → planejar mitigação, monitoramento e contingência, com revisão periódica.

### 10.5 Ágil ou dirigido a planos — o critério, não a ideologia

Sommerville:

> *"A questão de rotular o projeto como dirigido a planos ou ágil não é muito importante. A preocupação primária dos compradores é se possuem um sistema executável que satisfaça suas necessidades. Os desenvolvedores devem ser pragmáticos e escolher os métodos mais eficazes para o tipo de sistema a ser desenvolvido."*

**Sobre o sistema:**
1. **Tamanho.** Ágil funciona melhor com time pequeno, co-localizado, comunicando informalmente. Sistemas grandes empurram para planejamento.
2. **Tipo.** Sistemas que exigem muita análise **antes** da implementação (tempo real com temporização complexa) precisam de projeto detalhado para que a análise seja possível.
3. **Vida útil prevista.** Vida longa favorece mais documentação de projeto — com a ressalva de que documentação desatualizada não ajuda a manutenção.
4. **Controle externo.** Aprovação regulatória exige documentação detalhada como parte do plano de segurança.

**Sobre as pessoas:** nível de competência do time (ágil demanda habilidade mais alta, pois não há projeto detalhado a traduzir); organização (time distribuído ou terceirizado exige documentos); ferramentas (ágil se apoia em boa ferramenta de análise/visualização; sem elas, gere mais documentação).

**Sobre a organização:** exige-se especificação e projeto detalhados antes da implementação, talvez por contrato? Entrega incremental com feedback rápido é realista — há representante do cliente disponível? Há questões culturais (organizações de engenharia tradicional têm cultura dirigida a planos)?

Sommerville registra onde os princípios ágeis **atritam com a realidade organizacional**, e é isso que torna o critério utilizável: envolvimento do cliente depende de cliente disponível e representativo (stakeholders externos, como reguladores, não têm representação no time); acolher mudanças é difícil quando muitos stakeholders atribuem prioridades diferentes; entrega incremental atrita com ciclos longos de marketing; manter a simplicidade sofre sob pressão de prazo; "pessoas, não processos" pressupõe personalidades adequadas ao envolvimento intenso.

**Prática:** a maioria dos grandes projetos combina — tipicamente engenharia de requisitos dirigida a planos com implementação ágil. A pergunta correta nunca é "somos ágeis?", é **"qual o custo de errar, e quão rápido descobrimos que erramos?"**.

### 10.6 Comunicação e o profissional

- **É o que você diz e a maneira como diz** (Dica 10). Saiba o que quer dizer, conheça a audiência, escolha momento e meio, e **faça a comunicação ser diálogo** — se ninguém responde, você não comunicou.
- **Invista regularmente na sua carteira de conhecimentos** (Dica 8): conhecimento é ativo **que expira**. Diversifique, avalie risco, invista regularmente, reveja e reequilibre periodicamente.
- **Analise criticamente o que você lê e ouve** (Dica 9) — inclusive esta skill.
- **Não pense fora da caixa: encontre a caixa** (Dica 55). Problemas "impossíveis" quase sempre têm uma restrição falsa; identifique as restrições reais e pergunte por que cada uma existe.
- **Exceda gentilmente as expectativas** (Dica 69) e **assine seu trabalho** (Dica 70): responsabilidade explícita sustenta qualidade quando ninguém está olhando.
- **Forneça opções, não desculpas** (Dica 3), e **seja um catalisador da mudança** (Dica 5) — mudanças grandes raramente são aprovadas; mudanças pequenas e visivelmente bem-sucedidas se propagam.

Richards & Ford, negociação: entenda o que o stakeholder realmente precisa (frequentemente "cinco noves" significa "não quero ser acordado à noite"); **deixe tempo e custo por último**, porque encerram a conversa; use **dividir e conquistar** para reduzir requisitos vagos a partes negociáveis; seja **pragmático e visionário** ao mesmo tempo.

### 10.7 Os três métodos ágeis concretos — XP, Scrum e Kanban

§10.5 dá o **critério** para escolher entre ágil e dirigido a planos. Esta seção dá a **mecânica** dos três métodos que instanciam o ágil, na leitura de Valente. Distinção prévia que evita confusão em qualquer discussão:

- **Processo** = o conjunto de passos, tarefas e práticas que se usa para construir software. **Toda organização tem um processo** — pode ser ágil, waterfall ou caótico, mas existe.
- **Método** = uma definição concreta de processo. XP, Scrum e Kanban são métodos.
- **Regra de leitura de qualquer método:** *todo método é um conjunto de recomendações*; cabe à organização avaliar cada uma e adaptar. Não existem duas organizações rodando exatamente o mesmo processo, mesmo ambas dizendo "usamos Scrum".

**O núcleo comum a todos os métodos ágeis** (Manifesto Ágil, 2001 — indivíduos e interações > processos e ferramentas; software funcionando > documentação abrangente; colaboração com o cliente > negociação de contratos; resposta a mudanças > seguir um plano):

1. **Ciclos curtos e iterativos**, cada um produzindo incremento validado pelo cliente, começando pelo que é mais urgente **para o cliente**.
2. **Menos ênfase em documentação** — só o essencial.
3. **Menos ênfase em planos detalhados** — o entendimento emerge com os incrementos. O ponto é *avançar sob informação imperfeita*.
4. **Ausência de fase dedicada a design** (*big design up front*): o design é incremental.
5. **Times pequenos** (~10 pessoas; a "regra das duas pizzas").
6. **Práticas técnicas** que sustentam tudo isso: programação em pares, testes automatizados, integração contínua.

Cuidado com a leitura errada da figura clássica: **iteração ágil não é um mini-waterfall**, e **não obriga entrar em produção** ao fim de cada ciclo — a entrega é *potencialmente* implantável; colocar em produção envolve risco de negócio, marketing, treinamento, infraestrutura.

#### XP — valores, princípios e práticas

XP não é prescritivo: é definido por **valores** (abstratos) → **princípios** (a ponte) → **práticas** (concretas). Erro de adoção mais comum: pegar só as práticas. *Se a organização não está preparada para o modelo mental de XP, recomenda-se não adotar suas práticas.*

- **Valores:** comunicação, simplicidade, feedback, coragem, respeito, qualidade de vida.
- **Princípios:** humanidade (*peopleware* — o principal recurso são as pessoas), economicidade (software tem que gerar resultado econômico, não satisfazer vaidade intelectual), benefícios mútuos (toda decisão beneficia mais de um lado — testes ajudam quem escreve **e** quem mantém), melhorias contínuas, falhas acontecem (falha não é instrumento de punição), **baby steps**, responsabilidade pessoal (quem implementa uma história também a testa e mantém).

| Grupo | Práticas |
|---|---|
| **Processo** | representante dos clientes, histórias de usuário, iterações, releases, planejamento de releases, planejamento de iterações, planning poker, **slack** |
| **Programação** | design incremental, programação em pares, TDD, build automatizado, integração contínua |
| **Gerenciamento** | métricas de processo, ambiente de trabalho, contratos com escopo aberto |

**Estrutura temporal:** *releases* (2–3 meses) ⊃ *iterações* (1–3 semanas) ⊃ *tarefas* (poucos dias). O horizonte de planejamento é a release.

Para arrancar um projeto XP são necessários exatamente cinco itens: duração da iteração; número de iterações por release; histórias escritas pelo representante dos clientes; estimativas dos desenvolvedores; e a **velocidade** do time (story points por iteração). Então o representante prioriza, respeitando a velocidade como teto.

Regras de autoridade que o time costuma violar sem perceber:
- **Quem prioriza é o representante dos clientes, não o time.** Se X depende de Y e o cliente pediu X antes, implemente X com uma versão fixa/simplificada de Y — não inverta a ordem por conveniência técnica.
- **Histórias não contêm tarefas de infraestrutura** (o cliente é leigo). Histórias geram *tarefas*, e essas sim podem ser técnicas (instalar banco, configurar servidor).
- **Um projeto XP termina** quando o representante dos clientes decide que o que existe basta.

Práticas que merecem nota específica:
- **Design incremental**: "faça a coisa mais simples que possa funcionar" + **YAGNI**. Só funciona **em conjunto com refactoring contínuo** — sem refatorar, design incremental vira dívida. Ressalva do próprio método: times experientes já têm uma boa aproximação do design na primeira iteração, e nada impede uma tarefa técnica inicial para discutir design.
- **Programação em pares**: *driver* (teclado) + *navegador* (revisor/questionador), sessões de ~50 min com troca de par e papel. Ganhos medidos (survey Microsoft Research, 106 devs): menos bugs (62%), melhor qualidade (45%), disseminação de conhecimento (40%), aprendizado (40%); custo é o principal problema apontado (75%); par ideal = **habilidades complementares** (38%). A alternativa assíncrona hoje dominante é a **revisão de código**.
- **Propriedade coletiva do código**: qualquer um altera qualquer parte, sem pedir licença ao autor original.
- **Build automatizado**: build = compilar + empacotar + **rodar os testes**, sem intervenção humana. Meta declarada: **10 minutos**. Onde não der, a regra permanece: automatizar e reduzir.
- **Slack (folgas)**: tarefas adiáveis planejadas dentro da iteração (estudar tecnologia, escrever manual, projeto paralelo). Dois objetivos: *buffer* para o que estourar e ar para respirar. Time sem slack entrega no prazo até o primeiro imprevisto.
- **Ambiente de trabalho**: time dedicado (evitar pessoas fracionadas entre projetos), espaço informativo (o trabalho visível na parede) e **jornada sustentável de ~40h, inclusive na véspera da entrega**.
- **Contratos com escopo aberto** (pagamento por hora, rescindível): a alternativa ao escopo fechado, que empurra a contratada a entregar com defeito conhecido para não pagar multa. Coerente com "colaboração com o cliente mais que negociação de contratos".
- **Métricas de processo** que XP sugere para a gerência: **número de bugs em produção** e **tempo até o projeto gerar os primeiros resultados financeiros**.

#### Scrum — papéis, artefatos, eventos

**A diferença essencial para XP:** XP é método de desenvolvimento de software e traz práticas de programação; **Scrum é método de gerenciamento de projetos** — não necessariamente de software — e **não propõe nenhuma prática de programação**. Daí a combinação frequente na prática: Scrum para gestão + práticas de XP para engenharia. Time que adota Scrum e nada mais fica sem resposta para "como garantimos qualidade interna?".

| Categoria | Elementos |
|---|---|
| **Papéis** | Dono do Produto (PO), Scrum Master, desenvolvedores (3–9) |
| **Artefatos** | Backlog do Produto, Backlog do Sprint, Quadro Scrum, Gráfico de Burndown |
| **Eventos** | Planejamento do Sprint, Sprint, Reunião Diária, Revisão do Sprint, Retrospectiva |

- **Dono do Produto** = o representante dos clientes de XP: escreve e **prioriza** histórias, mantém o Backlog do Produto (artefato **dinâmico**), maximiza retorno do investimento, fica disponível para dúvidas. **Não pode ser um comitê** — comitê produz produto inchado de funcionalidades que atendem membros do comitê.
- **Scrum Master**: dono do *método*, não do time. Treina, facilita e **remove impedimentos** (o servidor que cai, o acesso que não sai). Não é gerente nem líder técnico; não precisa de formação em Computação. Pode acumular com desenvolvedor em time maduro, mas **nunca com Dono do Produto**.
- Times são **cross-funcionais** (contêm todas as especialidades necessárias) e **auto-organizáveis** (decidem como e por quem as histórias serão feitas). As decisões técnicas — linguagem, arquitetura, frameworks — são do time.
- **Sprint** (≤ 1 mês) entrega um *potentially shippable product*. O **objetivo do sprint não muda** depois de iniciado: Scrum acolhe mudança **entre** sprints; dentro do sprint o time tem blindagem. Essa é a função real do time-box.
- **Critérios de conclusão (*done*)**, combinados e conhecidos por todos: existem para impedir que se arraste tarefa mal feita para a coluna "concluído". Exemplo típico: testes de unidade escritos e passando + código revisado por outro membro + integrado no repositório.
- **Reunião diária** (15 min, em pé): o que fiz ontem, o que farei hoje, que impedimento tenho. Objetivo é **socializar o andamento**, não prestar contas — o ganho concreto é descobrir hoje que dois devs vão mexer no mesmo código.
- **Revisão do Sprint**: demonstração **ao vivo** para PO e stakeholders; história com problema volta ao Backlog do Produto. **Retrospectiva**: reflexão sobre processo, pessoas, relações e ferramentas — *não é reunião para lavar roupa suja*.

| Evento | Time-box (sprint de 1 mês) |
|---|---|
| Planejamento do Sprint | até 8 h |
| Sprint | menos de 1 mês |
| Reunião Diária | 15 min |
| Revisão do Sprint | até 4 h |
| Retrospectiva | até 3 h |

**Ainda existem gerentes com Scrum.** O time é autônomo para *implementar* o que o PO priorizou; permanecem gerenciais: contratar e alocar pessoas nos times, definir o objetivo e o escopo de cada time, RH, e avaliar se os resultados geram valor. **Squad** é sinônimo de time ágil (termo popularizado pela Spotify); *tribo* é um conjunto de squads.

#### Kanban — fluxo, WIP e Lei de Little

Kanban é **mais leve que Scrum**: sem sprints, sem eventos prescritos, sem papéis obrigatórios, sem critério prescrito de priorização. Sobrevive um artefato central: o **Quadro Kanban**, que já inclui o backlog.

- Colunas = **passos** do fluxo (ex.: Especificação → Implementação → Revisão de Código), cada um dividido em **em execução** e **concluídas**. Tarefa concluída num passo fica aguardando ser **puxada** para o próximo: Kanban é um sistema ***pull***, não *push*.
- **Limite WIP** (*Work in Progress*): teto de cartões por passo (em execução + concluídos; no último passo, só a primeira subcoluna). É o mecanismo do método para evitar sobrecarga — e, explicitamente, **o instrumento com que o time recusa trabalho empurrado de cima para baixo**. Essa é a função política do WIP, e é a razão pela qual times que "adotam Kanban sem limites WIP" não adotaram Kanban.

**Cálculo do WIP (Brechner, aplicação direta da Lei de Little):**

1. Estime o **lead time (LT)** médio de uma tarefa em cada passo — incluindo o tempo em fila.
2. Estime o **throughput (TP)** do passo mais lento (normalmente Implementação), em tarefas/dia.
3. **WIP(passo) = TP × LT(passo)**, arredondando para cima; some ~50% de margem para variação e bloqueios externos.

Exemplo: LT = 5 / 12 / 6 dias; time sustenta 8 tarefas/mês ⇒ TP = 8/21 ≈ 0,38 tarefa/dia ⇒ WIP ≈ 2 / 5 / 3.

**Lei de Little:** o número de itens num sistema de filas é a taxa de chegada × o tempo que cada item permanece no sistema — aqui, **WIP = TP × LT**. Consequência prática que decide discussões: com throughput fixo, **aumentar o WIP não aumenta a entrega, só alonga o lead time**. "Fazer mais coisas ao mesmo tempo" é matematicamente a forma de entregar mais devagar.

Kanban permite (mas não prescreve) reuniões diárias, revisões e retrospectivas, e recomenda **quadro físico** — o valor central é a visualização do trabalho e dos gargalos pelo time.

**Todo método tem seu mecanismo de proteção do ritmo**, e reconhecê-lo ajuda a não descartá-lo por engano: em Kanban é o limite WIP; em Scrum é o time-box do sprint com objetivo imutável; em Waterfall era a fase detalhada de especificação.

#### Quando **não** usar cada prática ágil

A pergunta útil não é "ágil serve para este sistema?", e sim **prática por prática** (complementa §10.5):

| Prática | Não use quando |
|---|---|
| **Design incremental** | O time não tem visão inicial do design, o domínio é novo e complexo, ou o custo de mudança futura é muito alto → faça uma fase inicial de análise e design |
| **Histórias de usuário** | O projeto é de área totalmente nova para o time e exige especificação detalhada desde o início |
| **Cliente integrado ao time** | Os requisitos são estáveis e plenamente conhecidos (ex.: compilador de linguagem consolidada) — não há o que um PO agregue |
| **Documentação leve** | Domínio exige certificação externa (médico, transporte, aviônica): a documentação **é** entregável obrigatório |
| **Times auto-organizáveis** | A cultura da organização é rigidamente hierárquica e exige prestação de contas diária — o atrito consumirá o benefício |
| **Contrato com escopo aberto** | O contratante precisa de previsibilidade de custo/prazo na assinatura ou não tem histórico de confiança com a contratada |

Duas práticas, no entanto, são hoje quase universais mesmo fora do ágil: **times pequenos** e **iterações** (ainda que de dois ou três meses).

#### Métodos iterativos anteriores ao ágil

- **Modelo Espiral** (Boehm, 1986): cada volta = definir objetivos e restrições → **avaliar alternativas e analisar riscos** → desenvolver e testar (gerando protótipo demonstrável) → planejar a próxima volta ou parar. Iterações de 6 a 24 meses. Sua contribuição durável é a **fase explícita de análise de risco** (§10.4).
- **Processo Unificado (UP/RUP)**: fases **inception** (viabilidade, orçamento, risco, escopo, *business case*) → **elaboração** (requisitos via casos de uso, arquitetura, plano; riscos controlados) → **construção** (projeto detalhado, implementação, testes) → **transição** (implantação, migração, treinamento). Disciplinas atravessam as fases com intensidades diferentes. Fortemente atado a UML e a ferramentas CASE — e é justamente esse acoplamento a ferramentas e diagramas que o ágil desmontou.

Ambos são úteis hoje menos como método a adotar e mais como **fonte de peças**: a análise de risco do Espiral e o *business case* da inception do UP faltam com frequência em times ágeis.

### 10.8 DevOps — da máquina do desenvolvedor até produção

**DevOps** é o movimento que aproxima as culturas de **desenvolvimento** e **operações** (administradores de rede e de banco, suporte) para tornar a implantação mais rápida e menos traumática. O anti-padrão que ele ataca tem nome: ***throw it over the wall*** — o time de desenvolvimento joga o sistema por cima do muro para o de operações, sem conversa nem no *hand-off*.

A frase que define o objetivo (Kim, Humble, Debois, Willis): *em vez de iniciar as implantações à meia-noite de sexta e passar o fim de semana concluindo-as, as implantações ocorrem em qualquer dia útil, com todos na empresa e sem que os clientes percebam — exceto quando encontram novas funcionalidades e correções*.

**O que DevOps não é:** não é um cargo novo que acumula desenvolver e operar. É **aproximação entre as duas áreas desde os primeiros sprints** — na prática, um profissional de operações participando do time ágil (tempo parcial ou integral, às vezes em mais de um time), antecipando problemas de desempenho, segurança e integração, e já escrevendo os scripts de instalação, administração e monitoramento **enquanto o código está sendo escrito**.

**Os seis princípios de entrega de software** (Humble & Farley) — cada um é diretamente acionável:

1. **Crie um processo repetível e confiável de entrega.** O mais importante: entregar não pode ser evento traumático com passos manuais. Colocar em produção deve ser **como apertar um botão**.
2. **Automatize tudo que for possível** — pré-requisito do anterior: build, testes, configuração e ativação de servidores e rede, carga do banco.
3. **Mantenha tudo em controle de versões** — *tudo* significa código, scripts de administração, documentação, páginas, dados. Consequência: voltar a um estado anterior é simples.
4. **Se um passo causa dor, execute-o com mais frequência e o quanto antes.** Não é masoquismo: é impedir que o problema se acumule. O exemplo canônico é integração contínua.
5. **Concluído significa pronto para entrega.** Quando alguém diz "está pronto" e a pergunta "pode entrar em produção?" revela pendências (não testado com dados reais, não documentado, não integrado com o sistema X), *done* não tinha semântica. **Concluído = 100% pronto para produção** (liga com os *done criteria* de §10.7).
6. **Todos são responsáveis pela entrega.** Fim dos silos.

#### Controle de versões

Um **VCS** dá duas coisas: um **repositório** com a versão corrente (código *e* documentação, configuração, manuais) e o **histórico**, que permite recuperar qualquer versão anterior — um *undo* no tempo.

| | **Centralizado** (SCCS, CVS, Subversion) | **Distribuído — DVCS** (BitKeeper, Mercurial, Git) |
|---|---|---|
| Arquitetura | cliente/servidor, **um** repositório | peer-to-peer: **cada máquina tem um servidor completo** |
| Operação básica | `commit` direto no servidor | `commit` local; `pull`/`push` sincronizam com o repositório de referência |

Vantagens do DVCS, todas consequência de o repositório ser local: **trabalhar offline**; **commits mais frequentes**, inclusive de implementações parciais, porque não chegam imediatamente ao repositório central; commits **mais rápidos**; e sincronização **não precisa ser sempre com o central** — dá para ter hierarquia de repositórios, com commits nascendo nas folhas.

Git nasceu em 2005, liderado por Torvalds, quando a empresa do BitKeeper revogou as licenças gratuitas usadas no desenvolvimento do Linux. **GitHub** (assim como GitLab e Bitbucket) é **serviço de hospedagem** que usa Git — a distinção importa: Git é o sistema; *fork* e *pull request* são conceitos da plataforma, não do Git.

**Multirepos × monorepos** — decisão organizacional, não técnica:

| | Multirepos | Monorepos (Google, Facebook, Microsoft) |
|---|---|---|
| Estrutura | um repositório por projeto | um repositório; projetos são diretórios |
| A favor | isolamento, permissões simples, clone pequeno | **fonte única de verdade** sobre versões; incentiva reúso e compartilhamento; **mudanças atômicas** (um commit para uma mudança que afeta dois sistemas); viabiliza **refactoring em larga escala** (renomear uma função usada por toda a organização em um commit) |
| Custo | mudança que cruza sistemas exige commits coordenados | exige **ferramentas para navegar em base gigante** — o Google precisou implementar plug-in próprio de IDE |

#### Integração contínua (CI)

**O problema que a motiva:** *feature branches* de longa duração. Alice trabalha 40 dias isolada; enquanto isso o master avança. No *merge* aparecem conflitos que **nenhuma ferramenta resolve sozinha**: a função `f1` que ela chamava foi renomeada, ganhou parâmetro ou sumiu; a função `f2` que ela mudou de milhas para quilômetros ganhou novos chamadores no master supondo milhas. Em sistema grande isso vira ***integration hell*** / ***merge hell***. E há um custo silencioso: branches longos criam **silos de conhecimento** — cada funcionalidade ganha dono, que adota padrões próprios de leiaute, telas e acesso a dados.

**A prática:** integrar no branch principal **com frequência** — Beck defende **intervalos menores que algumas horas**; Fowler estabelece o piso praticável de **pelo menos uma integração por dia por desenvolvedor**. A justificativa de Beck vale ser citada inteira: *programação em time não é um problema de dividir-e-conquistar; é dividir, conquistar e **integrar**. A duração de uma integração é imprevisível e pode facilmente levar mais tempo que a tarefa original de codificação — quanto mais você demorar para integrar, maiores e mais imprevisíveis serão os custos.*

**Práticas que precisam acompanhar CI:**
- **Build automatizado**, sem passo manual, o mais rápido possível (referência: **10 minutos**).
- **Testes automatizados** com boa cobertura, sobretudo de unidade (§7).
- **Servidor de CI**: a cada commit, clona o repositório, roda build completo e todos os testes, e notifica. Ele existe para pegar o que passa na máquina do dev e quebra fora dela — **arquivo esquecido no commit**, **versão de dependência diferente**.

**As duas regras de disciplina que fazem CI funcionar** (e que são as mais violadas):
1. **Build quebrado tem prioridade máxima** — nada numa empresa de software é mais urgente, porque o build quebrado bloqueia todo mundo. A correção pode ser simplesmente **reverter o commit**.
2. **Não avance antes do resultado do servidor** — não comece código novo, não entre em reunião, não vá almoçar nem para casa antes de saber se seu último commit passou.

**CI é compatível com branches?** Sim — **desde que sejam integrados diariamente**. A incompatibilidade não é com branch, é com **branch de vida longa**. Fowler é direto: *rodar build automático a cada commit sem integrar é **building contínuo**, pode ser bom, mas não é CI.* Chamar isso de CI é o autoengano mais comum da prática.

**Desenvolvimento baseado no trunk (TBD)**: se branch deve durar no máximo um dia, o custo/benefício de criá-lo some — então todo desenvolvimento ocorre no branch principal. É o que Google ("quase todo desenvolvimento ocorre no HEAD") e Facebook (front-end inteiro num único branch sempre estável) fazem.

**Quando não usar CI:** o limite de uma integração diária **não é lei da natureza**. Organização com sistema crítico, ou time iniciante, pode precisar de dois ou três dias — adaptação justificada pelo contexto é legítima, e experimentar intervalos ajuda a calibrar. E **CI não serve a projetos de código aberto com voluntários**, que não trabalham diariamente: ali o modelo certo é **forks + pull requests**.

#### Deployment contínuo (CD) e entrega contínua

**A diferença entre CI e CD é simples e o impacto é profundo:** com CI, o código integrado **não precisa estar pronto para produção** (pode ser uma tela feia ou uma função lenta, integrada só para os outros saberem que existe). Com **deployment contínuo, todo commit que chega no master entra em produção em questão de horas**.

Fluxo: dev desenvolve e testa localmente → commit → servidor de CI roda build e testes de unidade → algumas vezes por dia o servidor roda a bateria **exaustiva** (integração, interface, desempenho) sobre os commits ainda não implantados → passou, entra em produção.

Vantagens, na ordem de importância prática:
- **Reduz o tempo de entrega**: em vez de esperar F1…Fn ficarem prontas para uma release, cada uma sai quando fica pronta — **mais releases, com menos funcionalidades cada**.
- **Torna a implantação um não-evento**: acaba o dia D. Deadline é fonte de estresse, e perder um deadline pode adiar uma funcionalidade em meses.
- **Mantém o time motivado** e **favorece experimentação orientada a dados** — feedback de usuários reais em dias, não em meses (liga com §2.7).

Dado que revela o requisito escondido: no Facebook, cada desenvolvedor coloca em produção ~**3,5 atualizações por semana**, com média de **92 linhas adicionadas ou modificadas** por atualização. Ou seja, **CD exige a habilidade de quebrar qualquer tarefa em partes pequenas** — sem isso, a ferramenta não salva.

**Entrega contínua (*continuous delivery*)** é a versão mais fraca, e a correta para desktop, mobile e embarcado (você não quer ser notificado diariamente de nova versão do navegador ou do driver da impressora): **todo commit *pode* entrar em produção imediatamente — os devs programam como se fosse —, mas uma autoridade externa decide quando de fato liberar**. A distinção que resolve a confusão terminológica:

- **Deployment** = liberar uma versão **para os usuários**.
- **Delivery** = liberar uma versão **para ser objeto de deployment**.

Com deployment contínuo os dois são automáticos; com entrega contínua, o segundo passo é autorização manual.

#### Feature flags, release canário

**O problema:** se releases saem quase todo dia, como impedir que implementação parcial chegue ao usuário — **sem** voltar a usar branch longo (e o merge hell junto)?

**A solução:** integre o código parcial continuamente, porém **desabilitado**, guardado por um booleano — o **feature flag** (ou *feature toggle*). Localmente o dev liga o flag; em produção ele está desligado. Quando a funcionalidade é aprovada, **remove-se o código antigo e o flag** — a duplicação temporária é o preço consciente.

Prefira **tabela de flags** (`fft.isEnabled("novo-carrinho")`) a variáveis booleanas espalhadas: com biblioteca dedicada, o flag é configurado **fora do código**, sem editar e recompilar.

Escala real (estudo com 39 releases do Chrome, cinco anos): mais de **2.400 feature flags distintos**; de 263 na primeira versão analisada para 2.409 na última; média de **+73 e −43 flags por release**. A lição embutida no "−43": **flag que não é removido vira dívida** — cada um é um `if` a mais no código, e o conjunto multiplica os caminhos de execução (§7.7). Remover flag morto é tarefa de manutenção, não faxina opcional.

**Dois usos que justificam manter um flag vivo:**
- **Release canário**: libera a funcionalidade para uma fração pequena de usuários (5%, por exemplo) e amplia gradualmente se der certo — limitando o prejuízo de bugs que os testes não pegaram. O nome vem do canário que os mineiros levavam na gaiola: o gás matava o pássaro primeiro, e eles recuavam.
- **Testes A/B** (§2.7): é o feature flag que viabiliza servir duas versões simultâneas a grupos distintos.

### 10.9 Ética profissional e o limite do "foi pedido"

O ponto onde o julgamento técnico encontra o julgamento moral, e onde esta skill precisa ser explícita: **"o cliente pediu" e "o chefe mandou" não são respostas suficientes**.

Referências que existem para isso: o **Código de Ética da ACM**, o da **IEEE Computer Society** — específico para Engenharia de Software, e que prescreve que *engenheiros de software devem se comprometer em fazer da análise, especificação, projeto, desenvolvimento, teste e manutenção de software uma profissão benéfica e respeitada* — e, no Brasil, o **Código de Ética da SBC** (2013), sintético e claro. Entre seus deveres: contribuir para o bem-estar social e a inclusão; exercer o trabalho com responsabilidade e justiça, buscando a melhor solução; **manter-se atualizado**; **atuar dentro dos limites da própria competência**; guardar sigilo profissional; não discriminar por raça, sexo, religião, nacionalidade, cor, idade, estado civil ou qualquer outra condição humana; respeitar a legislação, o interesse social e direitos de terceiros; honrar compromissos, contratos, propriedade, *copyrights* e patentes; **nunca se apropriar de trabalho intelectual, iniciativas ou soluções de outras pessoas**.

**O caso que instancia tudo isso** — Volkswagen, 2015: mais de 11 milhões de carros com software que **detectava a situação de teste em laboratório** e, só nela, emitia poluentes dentro da norma. Reduzido ao essencial, o código continha:

```
if "carro sendo testado em laboratório"
    "emita poluentes dentro das normas"
else
    "emita poluentes fora das normas"
```

A pergunta que Valente deixa como exercício, e que vale como teste operacional: **o que você faria se seu chefe pedisse para escrever um `if` como esse?** Ela é útil justamente porque a decisão não é abstrata — chega como uma tarefa comum, num sprint comum, para um desenvolvedor comum.

Dados de contexto (Stack Overflow, 2018, +100 mil respondentes): quase **80%** disseram ter obrigação de considerar as implicações éticas do código que produzem; sobre quem é o responsável final por código antiético, **57,5%** apontaram a alta gerência e **23%** o próprio desenvolvedor; **58%** disseram que **não** escreveriam código eticamente duvidoso e **37%** que dependeria do que foi pedido.

**Como isso entra no trabalho, e não fica na declaração de princípios:**
- **É requisito não funcional.** Privacidade, não discriminação e transparência entram nos critérios de conclusão (§2.4) e nas funções de aptidão (§5.8) — ou não existem.
- **A recusa é técnica antes de ser moral**: "isso viola X" tem forma de argumento de engenharia, com registro em ADR (§5.7).
- **Assine seu trabalho** (§10.6). Responsabilidade explícita é o mecanismo que sustenta a decisão difícil quando ninguém está olhando.
- **Métrica e experimento não decidem valor** (§2.7): otimizar conversão é escolher entre alternativas **já consideradas aceitáveis**; a pergunta sobre aceitabilidade é anterior e não é respondida por dados.

---

## 11. Divergências entre os autores — e como decidir

**Meta-regras de arbitragem:**
- **M1 — Custo de reversão.** Quanto mais caro desfazer, mais antecipação se justifica.
- **M2 — Custo do erro.** Quanto mais caro o erro em produção (vidas, dinheiro, regulação), mais rigor formal e menos "descobrir depois".
- **M3 — Velocidade de feedback.** Descobre o erro em minutos? arrisque. Em meses? planeje.
- **M4 — "Depende" tem que ser instanciado.** Diga **de quê** depende e qual é o valor no seu caso.
- **M5 — Menos pior, não melhor.** Busque a menos pior no contexto, e registre por quê.

### 11.1 Comentários: "sempre um fracasso" vs. "documente"

**Posições.** Martin: comentários são sempre fracassos, porque mentem ao envelhecer. Hunt: DRY proíbe comentários que dupliquem o código, mas o **porquê** deve ser registrado, e a documentação deve ser **construída no código, não acrescentada como complemento** (Dica 68). GoF, Sommerville e Pressman assumem documentação de interface e de projeto como entregável.

**Análise.** Não é o mesmo objeto. Martin fala de comentários **dentro** de código de aplicação, cujo conteúdo é *o quê* e *como* — e ali está certo: essa informação já está no código, e duplicá-la viola DRY. Os demais falam de **contrato publicado** e de **justificativa** — informação que o código **não contém**.

**Critério.**
- Descreve *o que* o código faz → **apague e melhore o nome ou extraia uma função**.
- Descreve *por que* a decisão foi tomada, ou *por que a alternativa óbvia não serve* → **mantenha** (informação mais perecível e mais cara de reconstruir).
- Descreve contrato para consumidores que não leem seu código (API pública, biblioteca, serviço) → **documente formalmente**, com o mesmo rigor do código.
- Descreve algo que você não controla (comportamento estranho de terceiro, advertência) → **mantenha**.
- Sempre: **duplicação entre comentário e código é dívida com juros altos** — prefira a forma que falha no build quando divergem (asserção, teste, geração).

### 11.2 Projeto antecipado: integridade conceitual vs. design emergente

**Posições.** Brooks: integridade conceitual é o mais importante; deve proceder de uma mente; separe arquitetura de implementação; planeje jogar o primeiro fora. Fowler: projeto inicial *razoável*, não definitivo; estrutura emerge por refatoração; flexibilidade antecipada quase sempre desperdiça. Richards & Ford: decida no **último momento responsável**, itere, mas registre. Hunt: reversibilidade. Sommerville: em sistemas grandes, de vida longa, de tempo real ou regulados, planejamento e documentação antecipados são necessários.

**Análise.** A contradição é aparente: os autores falam de **níveis** e **classes de sistema** diferentes.
- **Integridade conceitual** (Brooks) é sobre **coerência de conceitos**, não sobre volume de projeto antecipado. Um sistema pode ser construído de forma totalmente emergente e ainda ter integridade conceitual — desde que poucas mentes concordantes governem o modelo. Evans institucionaliza isso com UBIQUITOUS LANGUAGE + MODEL-DRIVEN DESIGN + HANDS-ON MODELERS.
- **Design emergente** (Fowler/Beck) é sobre **estrutura de código**, onde o custo de reversão é baixo *desde que haja testes*.
- E Brooks **revisou** "planeje jogar um fora" na retrospectiva de 20 anos, trocando a metáfora de construção pela de **crescimento incremental**. O Brooks maduro concorda com Fowler mais do que a citação famosa sugere.

**Critério.** Antecipe projeto na proporção do **custo de reversão (M1)** e do **custo do erro (M2)**:

| Antecipe pouco (design emergente) | Antecipe muito (dirigido a planos) |
|---|---|
| Testes automatizados rápidos e confiáveis | Sem rede de segurança automatizada |
| Time pequeno e co-localizado | Time grande, distribuído ou terceirizado |
| Falha em produção é barata e reversível | Falha custa vidas, dinheiro ou licença |
| Domínio conhecido pelo time | Domínio novo, exige análise prévia |
| Estrutura interna do código | **Fronteiras entre componentes, contratos, formato de dados** |
| Reversível em horas | Migração de dados, contrato público, plataforma |

**Regra transversal:** *decisões baratas de reverter, decida cedo e corrija depois; decisões caras de reverter, adie até o último momento responsável e registre a justificativa.* Independentemente do lado, **a coerência conceitual é inegociável** — barata de manter, proibitivamente cara de restaurar.

### 11.3 Herança vs. composição — e quando herança ganha

**Posições.** GoF: prefira composição. Martin e Fowler concordam (Fowler oferece *Substituir Herança por Delegação*). Mas Fowler também oferece o inverso, **Substituir Delegação por Herança**, e GoF observa que sistemas puramente compostos são mais difíceis de entender.

**Critério.** Use **herança** só quando as três condições valem juntas: (a) a relação é genuinamente *é-um* em termos de **substituibilidade**; (b) a variação é **estável e conhecida em tempo de compilação**; (c) a subclasse **não recusa** parte da herança (o cheiro *Herança Recusada* invalida a escolha). Fora disso, **componha e delegue**.

Sinal de erro em qualquer direção: **delegação demais** e classes vazias = você compôs onde devia herdar (*Intermediário*); **hierarquias paralelas** ou subclasses que ignoram membros herdados = você herdou onde devia compor.

Distinção que dissolve metade das discussões: **herdar interface** (contrato, substituibilidade) é quase sempre seguro; **herdar implementação** é o que viola encapsulamento.

### 11.4 Flexibilidade antecipada vs. Generalidade Especulativa

**Posições.** GoF: encapsule o que varia; projete para mudança. Hooker (Pressman), 5º princípio: *esteja aberto para o futuro; resolva o problema geral; sempre pergunte "e se"*. Fowler: **Generalidade Especulativa é um cheiro**; sinal preciso — **os únicos usuários são os testes**. Richards & Ford: excesso de características arquiteturais gera soluções genéricas que raramente funcionam.

**Análise.** GoF e Hooker escrevem num contexto em que refatorar era caro (sem ferramenta de refatoração, sem suíte automatizada, releases longos). Nesse mundo, antecipar era racional. Fowler escreve **depois** de a refatoração ferramentada e o teste automatizado baratearem a mudança — e ele explicita essa mudança de ênfase (§8.6).

**Critério.** A pergunta não é *"isso vai mudar?"* — é **"quão difícil será refatorar a solução simples na flexível quando eu souber que preciso?"**:
- "Muito fácil" → **implemente o simples.** Caso da grande maioria da estrutura interna de código.
- "Difícil ou caro" → **antecipe a flexibilidade**; é aqui que os padrões de GoF ganham. Tipicamente: fronteiras entre componentes, contratos publicados, formatos de dados persistidos, integração com terceiros, pontos de extensão de framework.
- **Sempre:** aplique o teste de Fowler — se o único consumidor de uma abstração é o teste, ela é especulativa. Apague.
- **Sempre:** prefira **reversibilidade** (isolar o fornecedor atrás de uma interface sua) a **generalidade** (construir o mecanismo genérico). Reversibilidade é barata; generalidade é cara.

### 11.5 DRY vs. acoplamento — quando duplicar é correto

**Posições.** Hunt: DRY é um dos princípios mais importantes. Fowler: código duplicado é o cheiro nº 1 — mas a **Regra de Três** tolera a segunda ocorrência. Evans: **SEPARATE WAYS** manda declarar que dois contextos não têm conexão quando a integração custa mais do que vale. Richards & Ford: reúso de domínio entre serviços cria acoplamento — em microsserviços é explicitamente **evitado**.

**Análise.** DRY é sobre **conhecimento**, não sobre texto. Dois trechos idênticos que representam **regras diferentes que por acaso coincidem hoje** não são duplicação — unificá-los cria acoplamento falso, e o próximo requisito os fará divergir com um `if` no meio.

**Critério.**
1. **É o mesmo conhecimento ou coincidência textual?** *Se este requisito mudar, os dois lugares mudam juntos, sempre?* Se não, **não unifique**.
2. **A unificação cruza fronteira de contexto/serviço/time?** Se sim, o custo é acoplamento entre times e ciclos de implantação. Frequentemente **duplicar é correto** — SEPARATE WAYS (Evans) e a prática de arquiteturas distribuídas (Richards & Ford).
3. **Mesmo módulo/contexto e mesmo conhecimento?** **Unifique**, usando a Regra de Três como tolerância temporária, não como licença.
4. **Duplicação imposta pelo ambiente?** Gere a partir de fonte única, com processo ativo (§5.1).

Formulação unificada: **DRY dentro de um contexto; tolerância deliberada à duplicação entre contextos.** A conascência (§5.2) dá o instrumento: unificar transforma duplicação em conascência forte à distância — pior do que a duplicação que você eliminou.

### 11.6 Desempenho: "não otimize antes de medir" vs. "escolha o algoritmo certo"

**Posições.** Fowler: fatore bem, meça, otimize só os pontos quentes; atenção constante *não funciona*. Brooks e Sommerville: em tempo real, orce recursos por componente desde o projeto. Bhargava: escolher estrutura de dados e algoritmo é decisão fundamental, tomada antes de escrever.

**Análise.** Não há conflito: falam de **constantes** vs. **ordem de grandeza** vs. **garantia determinística**.

**Critério.**
- **Ordem de grandeza (assintótica)** → decida **no projeto**, sem medir. Trocar O(n²) por O(n log n) não é micro-otimização; é design, e nenhum profiler conserta depois sem reescrever.
- **Constantes e microdecisões** → **não antecipe**; meça primeiro. Aqui a regra de Fowler é soberana.
- **Requisito duro de tempo real** → **orce por componente desde o início**. Dado atrasado é dado errado; medir depois é tarde.
- Em todos os casos: **otimize em passos pequenos, medindo a cada passo, e desfaça o que não melhorou.**

### 11.7 Tamanho de função e classe: números vs. distância semântica

**Posições.** Martin: funções de poucas linhas, classes pequenas, SRP; admite não ter pesquisa para os números. Fowler: *"a chave aqui não é o tamanho do método, mas a **distância semântica** entre o que ele faz e como ele o faz."*

**Critério.** Use **distância semântica** como critério e os números de Martin como **alarme, não como lei**. Uma função longa cujo corpo inteiro está no mesmo nível de abstração e cujo nome descreve exatamente o que ela faz pode ser aceitável; uma função de sete linhas que mistura três níveis de abstração não é. Teste definitivo (§6.2): *você consegue extrair dela outra função cujo nome não seja mera reformulação da implementação?* Se sim, extraia.

Critério de Fowler para justificar extração mesmo quando a chamada é maior que o código substituído: **extraia se o nome do método explicar o propósito** — vale a pena extrair até uma única linha se ela precisa de explicação.

### 11.8 Padrões: catálogo vs. emergência

**Posições.** GoF: catálogo com procedimento de seleção e aplicação. Evans: padrões devem emergir do modelo e do domínio; padrão sem conceito de domínio correspondente é ruído. Fowler: **refatore *na direção* de padrões**, não *para* padrões. Hunt: *não programe por coincidência*.

**Critério.** Padrão é **vocabulário de diagnóstico**, não catálogo de partida.
- **Nunca** comece pelo padrão. Comece pela força que pressiona o design — uma das oito causas de reprojeto (§5.4) ou um cheiro (§8.4).
- Só então consulte *Aplicabilidade* e *Consequências*. Se as consequências não são aceitáveis no seu contexto, o padrão está errado, por mais bonito que seja.
- **Nomeie os participantes com nomes do seu domínio** — é literalmente o que reconcilia GoF e Evans: o padrão fica explícito **e** a linguagem ubíqua é preservada.
- Se você não sabe dizer que força o padrão está aliviando, está programando por coincidência.

### 11.9 Reúso: meta central vs. fonte de acoplamento

**Posições.** Pressman (Hooker, 6º princípio) e Sommerville: planeje visando reúso. GoF: frameworks e toolkits são veículos de reúso. Evans: separe subdomínios genéricos, considere prateleira — mas **não reutilize seu núcleo**. Richards & Ford: em microsserviços, **reúso de domínio é evitado deliberadamente**; reúso **operacional** (observabilidade, autenticação, log — via sidecar) é bem-vindo.

**Critério.** Separe os dois reúsos:
- **Reúso operacional/técnico** (infraestrutura transversal): **sempre bom.** Não acopla domínios.
- **Reúso de domínio**: bom **dentro** de um BOUNDED CONTEXT; caro e frequentemente errado **entre** contextos, porque cria conascência forte e acopla ciclos de implantação e times.
- Antes de extrair um componente "reutilizável": *quantos consumidores reais existem hoje, e pertencem ao mesmo contexto?* Menos de dois consumidores reais = generalidade especulativa (§11.4).
- Lembre a advertência de Pressman: **o retorno do reúso não é automático**; reúso mal planejado custa mais do que duplicação.

### 11.10 Documentação: quantidade e forma

**Posições.** Ágil: código expressivo e testes são a documentação primária. Sommerville e Pressman: sistemas de vida longa, regulados ou com times distribuídos precisam de documentação. Evans: o modelo e a linguagem ubíqua **no código** são a documentação central; documentos **complementam**. Richards & Ford: registre **decisões** (ADR) e diagramas, e cuidado com o *apego irracional pelo artefato*.

**Critério unificado.** Documente o que **o código não pode expressar**, e apenas isso:
1. **Decisões e justificativas** → ADR. **Sempre.** Único artefato tratado como universalmente obrigatório.
2. **Contratos publicados** → documentação formal de API/serviço.
3. **Visão do domínio** → uma página + glossário.
4. **Mapa de contextos e topologia** → diagramas em nível que sobreviva a mudanças (linhas pontilhadas para relações fracas; evite o diagrama cheio de detalhe que ninguém lê).
5. **Todo o resto** → deve estar no código e nos testes. Se você sente necessidade de documentar *como o código funciona*, o problema é o código.

Regra de sobrevivência: **documentação que duplica o código diverge do código.** Prefira sempre a forma que quebra o build quando a realidade muda (teste, asserção, função de aptidão) à forma que apenas envelhece em silêncio.

### 11.11 Modelos: documentar o sistema vs. esboçar para conversar

**Posições.** Os criadores da UML e o UP propõem o modelo como **blueprint**: documentação completa, produzida antes da codificação, em ferramenta CASE. A OMG foi além, com **MDD** — gerar o código a partir do modelo. Sommerville e Pressman tratam modelos como entregável de processo. Fowler e Valente reduzem o uso vivo ao **esboço**: informal, parcial, descartável.

**Análise.** O que envelhece não é o diagrama: é a **promessa de completude**. Modelo completo entra em conflito com a mesma regra de §11.10 — a forma que só envelhece em silêncio sempre diverge do código. O esboço não faz essa promessa: nasce para uma conversa e morre nela (ou é fotografado, como 58% dos desenvolvedores fazem).

**Regra.** Desenhe quando o diagrama vai ser **lido por alguém além de você**, nas duas janelas úteis: **antes** de codificar (engenharia avante — validar a proposta de classes) e **sobre código existente** (engenharia reversa — explicar). Use notação padrão parcial, não notação própria. Documento gráfico permanente só quando **exigido por contrato ou certificação** — e então ele é entregável, com custo de manutenção orçado. Detalhe em §4.8.

### 11.12 Story points: instrumento do time vs. métrica de gestão

**Posições.** XP e Scrum usam story points e velocidade para **planejar** o que cabe numa iteração. Gestão tende a lê-los como **produtividade** — comparando times, cobrando aumento de velocidade.

**Análise.** Ponto é **tamanho relativo**, calibrado por *aquele* time, com *aquele* domínio, *naquele* código. Não tem unidade absoluta: comparar velocidade entre times é comparar réguas diferentes. E, sendo estimativa do próprio time, vira meta autorrealizável — a inflação de pontos é a resposta racional à cobrança, e destrói exatamente a informação que tornava o número útil.

**Regra.** Velocidade é **entrada do planejamento e teto da priorização** (§10.7), nunca saída de avaliação. Vale a mesma regra de §5.12 e §7.7: **métrica não é meta**. Se a gerência precisa de número, XP oferece dois que medem resultado e não esforço: **bugs em produção** e **tempo até o projeto gerar resultado financeiro**.

### 11.13 Branch de funcionalidade vs. integração contínua

**Posições.** O modelo de *feature branch* isola o trabalho até estar pronto — e é o padrão em projetos de código aberto, via forks e pull requests. CI/TBD exige integração **diária** no branch principal, com código incompleto escondido atrás de feature flag.

**Análise.** Não é preferência de fluxo, é escolha sobre **onde pagar o custo da integração**. Branch longo adia o custo e o faz crescer de forma imprevisível (merge hell), além de criar silos de conhecimento. CI paga um pouco todo dia e exige, em troca, três coisas concretas: build automatizado rápido, boa suíte de testes e **capacidade de quebrar tarefas em partes pequenas** (Facebook: ~92 linhas por atualização).

**Regra por contexto:**

| Contexto | Modelo |
|---|---|
| Time dedicado, coeso, com build e testes automatizados | **CI + trunk based**, com feature flags |
| Contribuidores voluntários, assíncronos (código aberto) | **Forks + pull requests** — CI diária é inviável e não deve ser fingida |
| Sistema crítico, time iniciante, ou revisão obrigatória demorada | integração a cada 2–3 dias, declarada como adaptação consciente |

Em qualquer caso, chame pelo nome certo: rodar build a cada commit **sem integrar** é *building* contínuo, não integração contínua.

### 11.14 Correção do defeito vs. custo de oportunidade

**Posições.** A tradição de qualidade (Martin, Hunt, Pressman) diz para não conviver com defeito conhecido — janelas quebradas se multiplicam. A leitura econômica (aspectos econômicos do SWEBOK, XP com seu princípio de economicidade) diz que **toda decisão tem custo de oportunidade**: corrigir a lista de bugs B significa não implementar as funcionalidades F.

**Análise.** Não são a mesma pergunta. Defeito que **degrada o código** (janela quebrada, dívida com juros compostos) é problema de qualidade interna e se paga sozinho. Defeito **isolado, de baixa frequência, em código estável** é problema de alocação de recursos, e aí a comparação com F é legítima.

**Regra.** Enuncie as duas pontas explicitamente antes de decidir — quem defende só um lado ainda não formulou a decisão. E use M2 (§11): quanto mais caro o erro em produção (§1.2, classe do sistema), menos espaço o argumento econômico tem.

---

## 12. Anti-padrões e sinais de alarme

**De pensamento e decisão**
- **Homem das Cavernas Congelado** — projetar contra o trauma passado, superestimando um risco específico. Sintoma: justificativas na forma "uma vez isso deu errado comigo". Ação: distinguir risco técnico **genuíno** de **percebido**; quantificar impacto × probabilidade.
- **Cobertura dos Ativos / Feitiço do Tempo / Arquitetura por E-mail** — §5.7.
- **Paralisia de análise** — o outro extremo. Ação: último momento responsável, com data definida.
- **Programar por coincidência** — funciona e você não sabe por quê. Ação: pare, entenda, ou reescreva de forma que você entenda.
- **Arquiteto da torre de marfim** — decide sem tocar o código. Ação: HANDS-ON MODELERS (§4.2) e colaboração contínua com quem implementa.

**De estrutura**
- **Grande Bola de Lama** — nenhuma estrutura discernível. Ação: encapsular em componentes e decidir refatorar-ou-reconstruir por componente (§8.3).
- **Sinkhole de camadas** — requisições atravessam camadas sem lógica. Ação: abrir camadas ou reduzir o número delas.
- **Armadilha da entidade** — componentes derivados mecanicamente do modelo de dados (§5.5).
- **Objeto híbrido** — meio objeto, meio estrutura de dados (§6.5).
- **Acoplamento temporal oculto** — a ordem das chamadas importa e nada no código diz isso. Ação: torne a dependência **física** (cada chamada recebe o resultado da anterior).
- **Dependência lógica não física** — um módulo assume algo sobre outro sem que o compilador saiba. Ação: transforme em dependência física.
- **Generalidade Especulativa**, **Cirurgia com Rifle**, **Alteração Divergente** — §8.4.

**De entrega e integração**
- **Branch de funcionalidade de vida longa** → *integration/merge hell* e silos de conhecimento (§10.8, §11.13).
- **"Fazemos CI" rodando build a cada commit sem integrar** — é *building* contínuo (§10.8).
- **Build quebrado convivendo** — bloqueia todo o time; prioridade máxima é consertar ou reverter.
- **Ir almoçar/para casa sem o resultado do servidor de CI.**
- **Feature flag que ninguém remove** — cada um é um `if` permanente; o conjunto multiplica caminhos de execução (Chrome removia ~43 por release, e ainda assim acumulou 2.400).
- **Passo manual no caminho para produção** — se dói, você vai fazer menos vezes, e cada vez vai doer mais.
- **"Concluído" sem semântica** — *done* que ainda precisa de teste com dados reais, documentação ou integração (§10.8).

**De processo**
- **Adicionar pessoas a projeto atrasado** (Lei de Brooks, §10.2).
- **Gold plating** — sofisticar a história além do que o cliente pediu (§2.4).
- **História técnica** ("o sistema deve usar React") — viola o V de INVEST; isso é tarefa, ou *spike* (§2.4).
- **Comitê no lugar do Dono do Produto** — produz produto inchado de funcionalidades que atendem membros do comitê (§10.7).
- **Kanban sem limite WIP** — sem a trava, o método perde justamente o mecanismo que recusa trabalho empurrado de cima (§10.7).
- **Alterar o objetivo do sprint no meio do sprint** — destrói a blindagem que o time-box existe para dar.
- **Retrospectiva usada para lavar roupa suja**, em vez de melhorar processo, pessoas, relações e ferramentas.
- **Adotar práticas de XP sem os valores e princípios** — o próprio método desaconselha.
- **Encerrar teste A/B assim que o ganho aparece**, antes do tamanho de amostra planejado (§2.7).
- **MVP sem hipótese e sem critério de refutação** — entrega pequena com nome bonito, que nunca "falha".
- **Métrica de vaidade** guiando decisão de produto (§2.7).
- **Métrica virando meta** — LOC, cobertura, complexidade, velocidade (§5.12, §7.7, §11.12).
- **Over-engineering em sistema classe C** — bala de canhão para matar formiga (§1.2).

**De testes**
- **Teste flaky tolerado** — ~16% dos testes do Google já tiveram esse problema; o dano é a erosão da confiança na suíte (§7.6).
- **`sleep` para "esperar" código assíncrono** em vez de extrair a versão síncrona (§7.8).
- **Mock de tudo** — acopla o teste às entranhas do código testado e torna a suíte frágil (§7.9).
- **Mock em teste de integração** — anula o propósito do nível (§7.5).
- **Teste com `if` e laços** (§7.6).
- **Pirâmide invertida** — muitos testes de sistema, poucos de unidade: caro, lento e frágil (§7.5).
- **Efeito do segundo sistema.**
- **"Não temos tempo para refatorar"** fora da véspera de prazo — diagnóstico invertido (§8.3).
- **Testes como cidadãos de segunda classe** — "rápido e porco" no teste degrada o código de produção em poucos meses (§7.1).
- **Cobertura como meta** em vez de detector de omissão (§7.3).
- **Janelas quebradas toleradas** (§6.9).
- **Protótipo promovido a produção** (§2.3).
- **Otimização por atenção constante** (§9.2).

---

## 13. Checklists operacionais

### 13.1 Antes de aceitar um requisito

- [ ] A história tem **cartão, conversas e confirmação** — ou só o cartão? (§2.4)
- [ ] Passa em **INVEST**? Em especial: tem valor para o cliente e critério de aceitação **objetivo**?
- [ ] Quem escreveu os **testes de aceitação** foi o cliente? (antídoto ao gold plating)
- [ ] Requisito não funcional virou **critério de conclusão**, em vez de item de backlog?
- [ ] Se é MVP: qual é a **hipótese** e o que a **refutaria**?
- [ ] Se é teste A/B: métrica, tamanho de amostra e duração definidos **antes**? Rodou um A/A?

### 13.2 Antes de começar a construir
- [ ] Sei qual é o **CORE DOMAIN** e o que é genérico?
- [ ] Existe glossário/linguagem ubíqua, e o código a usa?
- [ ] As **características arquiteturais** foram nomeadas, **limitadas em número** e cada uma é **mensurável**?
- [ ] O que é arriscado ou desconhecido está isolado num **protótipo descartável** declarado como tal?
- [ ] Existe um **esqueleto ponta a ponta** (tracer bullet) planejado?
- [ ] Riscos foram identificados individualmente antes de discutidos em grupo? Tecnologia desconhecida foi marcada como risco máximo?
- [ ] Build, teste e implantação são **um comando cada**?
- [ ] Controle de versão desde o primeiro arquivo?

### 13.3 Antes de decidir arquitetura ou tecnologia
- [ ] Consigo enunciar **pelo menos dois** trade-offs da opção escolhida? (Se não, ainda não os encontrei.)
- [ ] Qual o **custo de reverter**? A decisão pode ser adiada sem bloquear ninguém?
- [ ] Isolei o fornecedor/tecnologia atrás de uma interface **minha**?
- [ ] Escrevi o **ADR** com contexto, decisão, justificativa técnica **e** de negócio, e consequências?
- [ ] Existe uma **função de aptidão** que detecta a violação desta decisão automaticamente?

### 13.4 Antes de escrever código
- [ ] Existe um teste que falha?
- [ ] Sei em que nível de abstração estou trabalhando?
- [ ] O nome que vou dar responde *por que existe, o que faz, como é usado*?
- [ ] Estou com o chapéu de "adicionar funcionalidade" ou o de "refatorar"? (Nunca os dois.)

### 13.5 Antes de commit / revisão
- [ ] Todos os testes passam, e rodei a suíte inteira?
- [ ] Passei os cheiros (§8.4) sobre o que toquei?
- [ ] Nenhum comentário reafirma o que o código diz; o *porquê* não trivial está registrado?
- [ ] Nenhuma função com argumento booleano, argumento de saída, ou mais de três parâmetros sem justificativa?
- [ ] Nenhum número mágico, nenhum código comentado, nenhuma função morta?
- [ ] Cada bug corrigido virou um teste que impede o retorno?
- [ ] O código está mais limpo do que eu o encontrei?

### 13.6 Antes de automatizar entrega e implantação

- [ ] Build, testes e implantação são **um comando cada**, sem passo manual?
- [ ] O build roda em tempo tolerável (referência: **10 minutos**)?
- [ ] Existe **servidor de CI** rodando build + testes a cada commit, com notificação?
- [ ] Todo mundo integra no branch principal **pelo menos uma vez por dia**? Se não, isso está **declarado como adaptação**, e não chamado de CI?
- [ ] Código incompleto entra escondido atrás de **feature flag**, e existe alguém responsável por **removê-lo depois**?
- [ ] Está tudo em controle de versões — inclusive scripts, configuração e documentação?
- [ ] Existe **rollback** e, para mudança arriscada, **release canário**?
- [ ] "Concluído" significa **pronto para produção** para todo o time?

### 13.7 Antes de entregar
- [ ] O escopo de qualidade foi **decidido com o usuário**, não presumido?
- [ ] O que ficou de fora está registrado como dívida consciente, com juros estimados?
- [ ] Existe caminho de rollback?
- [ ] A documentação obrigatória (ADRs, contratos, visão, mapa de contextos) está atualizada — e nada além disso foi produzido?
- [ ] As estimativas foram comparadas com o realizado e a diferença investigada?

---

## 14. Frases-âncora

- Tudo é trade-off; se você não achou a contrapartida, não olhou o suficiente.
- **O porquê importa mais que o como.**
- Nunca mire na melhor arquitetura, mire na **menos pior**.
- Não colete requisitos: **cave-os**.
- Não há decisões definitivas — mas há decisões caras de reverter, e essas se adiam.
- Faça a pergunta, não apresente a solução.
- Programadores conhecem os benefícios de tudo e os trade-offs de nada.
- Comentários não são um bem — são um fracasso tolerado; o *porquê* é a exceção.
- Três vezes e você refatora.
- Você não decide refatorar: você refatora porque quer fazer outra coisa.
- Um chapéu de cada vez.
- Não é o tamanho do método: é a **distância semântica**.
- Encapsule o conceito que varia — mas só depois de saber que ele varia.
- Duplicação é conhecimento repetido, não texto repetido.
- Escreva software ajustável primeiro; ajuste depois, medindo.
- Acrescentar mão de obra a um projeto atrasado torna-o mais tardio.
- Não existe bala de prata: a dificuldade é essencial, não acidental.
- Crescer, não construir.
- Teste seu software, ou seus usuários o farão.
- Não programe por coincidência.
- Deixe o acampamento mais limpo do que você o encontrou.
- **Testes mostram a presença de bugs, mas não a sua ausência.** (Dijkstra)
- Verificação: estamos construindo o sistema **corretamente**? Validação: estamos construindo o **sistema correto**?
- Se um passo causa dor, **execute-o com mais frequência e o quanto antes**.
- **Concluído significa pronto para entrega.**
- Não é dividir-e-conquistar: é dividir, conquistar **e integrar**.
- Build automático a cada commit sem integrar é *building* contínuo, não integração contínua.
- Colocar em produção deve ser **como apertar um botão**.
- Engenharia de Software em sistema casual é **bala de canhão para matar formiga**.
- Um dos dias mais produtivos da minha vida foi quando **deletei 1.000 linhas de código**. (Thompson)
- Código sem testes é **código legado**. (Feathers)
- **Não existe história técnica**: se não tem valor para o cliente, é tarefa.
- A divergência na estimativa **é o produto** — o número é o subproduto.
- Aumentar o WIP não aumenta a entrega: **alonga o lead time** (Lei de Little).
- Legado **não** significa irrelevante.
- Métrica não é meta — LOC, cobertura, complexidade e velocidade inclusive.

---

## 15. Mapa das fontes

| Obra | Papel nesta síntese |
|---|---|
| **Brooks — O Mítico Homem-Mês** | Essência vs. acidente; integridade conceitual; Lei de Brooks; efeito do segundo sistema; crescer em vez de construir; ausência de bala de prata |
| **Hunt & Thomas — O Programador Pragmático** | Filosofia e heurísticas do dia a dia (70 dicas); DRY; ortogonalidade; reversibilidade; tracer bullets vs. protótipos; estimativa; contratos; automação; postura profissional |
| **Martin — Código Limpo** | Nomes, funções, comentários, formatação, objetos vs. estruturas de dados, erros, limites, testes limpos e F.I.R.S.T., classes e SRP, sistemas, emergência, catálogo de odores e heurísticas |
| **Fowler — Refatoração** | Definição e disciplina; dois chapéus; quando e quando não refatorar; dívida técnica; catálogo de cheiros e de movimentos; refatoração e projeto; refatoração e desempenho |
| **Evans — Domain-Driven Design** | Linguagem ubíqua; model-driven design; blocos de construção; supple design; bounded context e integração; destilação; refatoração rumo a insight mais profundo |
| **Gamma, Helm, Johnson & Vlissides — Padrões de Projeto** | Princípios de reutilização; causas de reprojeto; catálogo de intenções; procedimento de seleção e aplicação; aplicação a aplicações, toolkits e frameworks |
| **Richards & Ford — Fundamentos da Arquitetura de Software** | Leis da arquitetura; características arquiteturais e seus três critérios; modularidade, coesão, acoplamento e conascência; estilos e sua escolha; quantum; ADRs; funções de aptidão; risk storming; equipes e negociação |
| **Sommerville — Engenharia de Software** | Processos; critérios entre ágil e dirigido a planos; requisitos; verificação e validação; dependabilidade; evolução, manutenção, leis de Lehman e economia da manutenibilidade |
| **Pressman & Maxim — Engenharia de Software** | Anatomia genérica do processo; adaptação do processo; princípios de Hooker; qualidade, métricas, revisões técnicas e gestão de riscos |
| **Bhargava — Entendendo Algoritmos** | Big O e ordens de grandeza; arrays vs. listas; tabelas hash; grafos, busca em largura e Dijkstra; guloso, aproximação e NP-completo; programação dinâmica |
| **Valente — Engenharia de Software Moderna** | Vocabulário e calibragem (defeito/falha, verificação/validação, qualidade externa/interna, sistemas ABC); mecânica concreta de XP, Scrum e Kanban, e quando **não** usar cada prática ágil; histórias de usuário (3C, INVEST), casos de uso, MVP e testes A/B; UML como esboço; camadas, três camadas, MVC e SPA; métricas de código (LOC, LCOM, CBO, complexidade ciclomática); pirâmide de testes, cobertura, testabilidade, duplos e TDD; taxonomia de manutenção; DevOps, controle de versões, CI, CD, entrega contínua e feature flags; ética profissional |

---

### Nota de uso final

Esta skill não substitui o julgamento. Ela codifica o julgamento que onze autores exerceram e explicita os pontos em que ele diverge. Quando um caso concreto não se encaixar em nenhuma regra acima, aplique a única regra que todos respeitam sem exceção: **enuncie o trade-off, escolha a opção menos pior para o contexto, registre por que — e prepare-se para estar errado de um jeito barato de corrigir.**
